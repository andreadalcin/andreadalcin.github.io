#include <stdio.h>
#include <stdlib.h>
#include "list.h"

#define N 10

Lista add_ordered(Lista, TipoElem);

int main() {
    Lista list = NULL;
    int n;

    // Popola la lista con elementi da esempio
    for (int i = N - 1; i >= 0; i--) {
        if (i != 1) {
            list = insert_first(list, i);
        }
    }
    print_list(list);

    // Inserisci elemento dato da utente
    printf("Inserisci un numero nella lista: ");
    scanf("%d", &n);

    // Aggiungi n alla lista mantenendo l'ordinamento
    list = add_ordered(list, n);

    // Stampa la lista
    print_list(list);

    return 0;
}

Lista add_ordered(Lista list, TipoElem num) {
    Lista pnt = (Lista) malloc(sizeof(Elem));
    pnt->info = num;
    pnt->prox = NULL;

    // Se la lista è vuota, l'elemento è esso stesso la lista
    if (list == NULL) {
        return pnt;
    }

    // Se il primo elemento della lista è maggiore, la testa della lista diventa il puntatore stesso
    if (list->info > num) {
        pnt->prox = list;
        return pnt;
    }

    // Scorri la lista fino all'elemento della lista minore o uguale
    Lista curr = list;
    while (curr->prox != NULL && curr->prox->info <= num) {
        curr = curr->prox;
    }

    pnt->prox = curr->prox;
    curr->prox = pnt;
    return list;
}

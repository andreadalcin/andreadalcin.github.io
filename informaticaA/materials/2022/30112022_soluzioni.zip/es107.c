#include <stdio.h>
#include <stdlib.h>
#include "list.h"

#define N 10

Lista rmv_duplicates(Lista);

int main() {
    // Popola la lista con elementi da esempio
    Lista list = NULL;
    list = insert_first(list, 1);
    list = insert_first(list, 3);
    list = insert_first(list, 3);
    list = insert_first(list, 1);
    list = insert_first(list, 3);
    list = insert_first(list, 1);
    list = insert_first(list, 3);
    list = insert_first(list, 2);
    list = insert_first(list, 3);
    print_list(list);

    // Rimuovi i primi n elementi dalla lista
    list = rmv_duplicates(list);
    print_list(list);

    return 0;
}


Lista rmv_duplicates(Lista list) {
    if (list == NULL) {
        return list;
    }

    Lista cur1 = list, prev2, cur2;
    while (cur1 != NULL && cur1->prox != NULL) {
        prev2 = cur1;
        cur2 = cur1->prox;

        while (cur2 != NULL) {
            if (cur1->info == cur2->info) {
                prev2->prox = cur2->prox;
                free(cur2);
                cur2 = prev2->prox;
            } else {
                prev2 = prev2->prox;
                cur2 = cur2->prox;
            }
        }

        cur1 = cur1->prox;
    }

    return list;
}

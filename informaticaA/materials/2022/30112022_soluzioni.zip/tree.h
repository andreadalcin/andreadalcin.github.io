typedef int TipoElem;

typedef struct El {
    int val;
    struct El *left;
    struct El *right;
} Node;

typedef Node *Tree;

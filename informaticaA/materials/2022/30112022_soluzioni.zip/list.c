#include <stdio.h>
#include <stdlib.h>
#include "list.h"

Lista insert_first(Lista lista, TipoElem elem) {
    Lista punt = (Lista) malloc(sizeof(Elem));
    punt->info = elem;
    punt->prox = lista;
    return punt;
}

void print_list(Lista lista) {
    while (lista != NULL) {
        printf("%d ", lista->info);
        lista = lista->prox;
    }
    printf("\n");
}
#include <stdio.h>
#include "list.h"

#define N 10

int sum(Lista, int);
int sum_rc(Lista, int);

int main() {
    int M = 2;

    Lista list = NULL;
    int i;

    for (i = N; i > 0; i--) {
        list = insert_first(list, i);
    }

    printf("Somma degli elementi multipli di %d: %d\n", M, sum(list, M));
    printf("Somma (ricorsiva) degli elementi multipli di %d: %d", M, sum_rc(list, M));

    return 0;
}

int sum(Lista list, int M) {
    // Ritorna -1 se la lista è vuota
    if (list == NULL) {
        return -1;
    }

    // Calcola la somma dei soli elementi multipli di M
    int sum = 0;
    while (list != NULL) {
        if (list->info % M == 0) {
            sum += list->info;
        }
        list = list->prox;
    }

    return sum;
}

int sum_rc(Lista list, int M) {
    if (list == NULL) {
        return -1;
    }

    if (list->prox == NULL) {
        if (list->info % M == 0) {
            return list->info;
        }
        return 0;
    }

    if (list->info % M != 0) {
        return sum_rc(list->prox, M);
    }

    return list->info + sum_rc(list->prox, M);
}

typedef int TipoElem;

typedef struct EL {
    TipoElem info;
    struct EL * prox;
} Elem;

typedef Elem * Lista;

Lista insert_first(Lista lista, TipoElem elem);

void print_list(Lista lista);
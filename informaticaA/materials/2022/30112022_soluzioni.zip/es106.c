#include <stdio.h>
#include <stdlib.h>
#include "list.h"

#define N 10

Lista invert_1(Lista, int);
Lista invert_2(Lista);

int main() {
    Lista list = NULL;
    int n;

    // Popola la lista con elementi da esempio
    for (int i = N - 1; i >= 0; i--) {
        list = insert_first(list, i);
    }
    print_list(list);

    // Rimuovi i primi n elementi dalla lista
    Lista inverted = invert_1(list, 0);
    print_list(inverted);
    print_list(invert_2(list));

    return 0;
}


Lista invert_1(Lista list, int clean) {
    Lista inverted = NULL;

    Lista curr = list;
    while (curr != NULL) {
        inverted = insert_first(inverted, curr->info);

        Lista tmp = curr;
        curr = curr->prox;

        if (clean) {
            free(tmp);
        }
    }

    return inverted;
}

Lista invert_2(Lista lista) {
    Lista tmp, prev = NULL;
    if (lista == NULL) {
        return lista;
    }

    while (lista->prox != NULL) {
        tmp = prev;
        prev = lista;
        lista = lista->prox;
        prev->prox = tmp;
    }
    lista->prox = prev;

    return lista;
}

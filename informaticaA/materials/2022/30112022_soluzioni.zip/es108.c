#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

int size(Tree);
int leaves(Tree);
int branches(Tree);
int branches2(Tree);

int main() {
    // Popola la lista con elementi da esempio
    Tree tree = (Tree) malloc(sizeof(Node));
    tree->val = 0;

    int _size = size(tree);
    int _leaves = leaves(tree);
    int _branches = branches(tree);
    int _branches2 = branches2(tree);

    return 0;
}

int size(Tree t) {
    if (t == NULL) {
        return 0;
    } else {
        return 1 + size(t->left) + size(t->right);
    }
}

int leaves(Tree t) {
    if (t == NULL) {
        return 0;
    }
    if (t->left == NULL && t->right == NULL) {
        return 1;
    }
    return leaves(t->right) + leaves(t->left);
}

int branches(Tree t) {
    if (t == NULL || (t->left == NULL && t->right == NULL)) {
        return 0;
    }
    return 1 + branches(t->right) + branches(t->left);
}

int branches2(Tree t) {
    return size(t) - leaves(t);
}

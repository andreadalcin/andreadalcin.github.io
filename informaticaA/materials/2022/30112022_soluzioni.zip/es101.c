#include <stdio.h>
#include "list.h"

#define N 10

int find(Lista, TipoElem);

int main() {
    Lista list = NULL;
    int i;

    for (i = N; i > 0; i--) {
        list = insert_first(list, i);
    }

    int n;
    printf("Inserisci elemento da trovare: ");
    scanf("%d", &n);

    if (find(list, n)) {
        printf("L'elemento %d è presente nella lista", n);
    } else {
        printf("L'elemento %d NON è presente nella lista", n);
    }

    return 0;
}

int find(Lista list, TipoElem n) {
    while (list != NULL) {
        if (list->info == n) {
            return 1;
        }
        list = list->prox;
    }
    return 0;
}

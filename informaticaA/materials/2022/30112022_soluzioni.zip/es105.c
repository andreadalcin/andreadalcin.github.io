#include <stdio.h>
#include <stdlib.h>
#include "list.h"

#define N 10

Lista rmv(Lista, int);

int main() {
    Lista list = NULL;
    int n;

    // Popola la lista con elementi da esempio
    for (int i = N - 1; i >= 0; i--) {
        list = insert_first(list, i);
    }
    print_list(list);

    // Inserisci elemento da rimuovere
    printf("Quanti elementi da rimuovere dalla lista? ");
    scanf("%d", &n);

    // Rimuovi i primi n elementi dalla lista
    list = rmv(list, n);
    print_list(list);

    return 0;
}

Lista rmv(Lista list, int num) {
    int i = 0;
    while (list != NULL && i < num) {
        Lista tmp = list;
        list = list->prox;
        free(tmp);
        i++;
    }
    return list;
}

#include <stdio.h>
#include <stdlib.h>
#include "list.h"

#define N 10

Lista rmv(Lista, TipoElem);

int main() {
    Lista list = NULL;
    int n;

    // Popola la lista con elementi da esempio
    for (int i = N - 1; i >= 0; i--) {
        list = insert_first(list, i);
    }
    print_list(list);

    // Inserisci elemento da rimuovere
    printf("Rimuovi un numero dalla lista: ");
    scanf("%d", &n);

    // Rimuovi n dalla lista
    list = rmv(list, n);
    print_list(list);

    return 0;
}

Lista rmv(Lista list, TipoElem num) {
    Lista prev = NULL, curr = list;
    while (curr != NULL && curr->info != num) {
        prev = curr;
        curr = curr->prox;
    }

    if (curr == NULL) {
        return list;
    } else if (prev == NULL) {
        // Rimuovi primo elemento della lista
        list = curr->prox;
    } else {
        // Rimuovi elemento nella lista
        prev->prox = curr->prox;
    }

    free(curr);
    return list;
}

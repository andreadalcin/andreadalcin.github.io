#include <stdio.h>
#include <string.h>
#include <limits.h>

#define DIM 100

/*
 * Scrivi un programma in C per trovare la parola più grande e quella più piccola in una stringa.
 */
int main() {
    char str[DIM], str_long[DIM], str_short[DIM];
    int i, sublen, word_start, len, long_len, long_start, short_len, short_start;

    printf("Inserisci la stringa: ");
    fgets(str, DIM, stdin);
    // Dobbiamo rimuovere il newline '\n'. strcspn conta il numero di caratteri fino a '\n'.
    str[strcspn(str,"\n")] = '\0';

    len = (int) strlen(str);
    long_len = INT_MIN;
    short_len = INT_MAX;
    long_start = -1;
    short_start = -1;
    word_start = 0;

    for (i = 0; i <= len; i++) {
        if (str[i] == ' ' || str[i] == '\0') {
            sublen = i - word_start;
            if (sublen > 0) {
                if (sublen > long_len) {
                    long_start = word_start;
                    long_len = sublen;
                }
                if (sublen < short_len) {
                    short_start = word_start;
                    short_len = sublen;
                }
            }
            word_start = i + 1;
        }
    }

    if (long_start >= 0) {
        strncpy(str_long, str + long_start, long_len);
        str_long[long_len] = '\0';
        printf("La parola più lunga è: %s\n", str_long);
    }

    if (short_start >= 0) {
        strncpy(str_short, str + short_start, short_len);
        str_short[short_len] = '\0';
        printf("La parola più corta è: %s\n", str_short);
    }
}
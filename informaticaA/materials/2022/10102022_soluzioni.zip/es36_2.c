#include <stdio.h>

#define DIM 100

/*
 * Scrivi un programma in C per convertire i caratteri di una stringa da uppercase a lowercase e viceversa.
 */
int main() {
    char str[DIM];
    int i;

    printf("Inserisci la stringa: ");
    scanf("%s", str);

    for (i = 0; str[i] != '\0'; i++) {
        if (str[i] >= 0x41 && str[i] <= 0x5A || str[i] >= 0x61 && str[i] <= 0x7A) {
            str[i] = (char) (str[i] ^ (1 << 5));
        }
    }

    printf("%s", str);
    return 0;
}
#include <stdio.h>

#define DIM 100

int main() {
    char str[DIM], tgt[3 * DIM];
    int i, j;

    printf("Inserisci la stringa da farfalizzare: ");
    scanf("%s", str);

    j = 0;

    for (i = 0; str[i] != '\0'; i++) {
        if (str[i] == 'a' ||
            str[i] == 'e' ||
            str[i] == 'i' ||
            str[i] == 'o' ||
            str[i] == 'u') {
            tgt[j++] = str[i];
            tgt[j++] = 'f';
            tgt[j++] = str[i];
        } else {
            tgt[j++] = str[i];
        }
    }

    tgt[j] = '\0';
    printf("La stringa in farfallese è: %s", tgt);

    return 0;
}
#include <stdio.h>

#define DIM 100
#define HIST_DIM 256

int main() {
    char str1[DIM];
    char str2[DIM];
    int hist1[HIST_DIM] = { 0 };
    int hist2[HIST_DIM] = { 0 };
    int i, flag;

    printf("Inserisci la prima stringa: ");
    scanf("%s", str1);
    printf("Inserisci la seconda stringa: ");
    scanf("%s", str2);

    for (i = 0; str1[i] != '\0'; i++) {
        hist1[str1[i]]++;
    }

    for (i = 0; str2[i] != '\0'; i++) {
        hist2[str2[i]]++;
    }

    flag = 1;
    for (i = 0; i < HIST_DIM && flag; i++) {
        if (hist1[i] != hist2[i]) {
            flag = 0;
        }
    }

    if (flag) {
        printf("Le parole sono anagrammi");
    } else {
        printf("Le parole NON sono anagrammi");
    }

    return 0;
}
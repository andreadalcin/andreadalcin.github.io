#include <stdio.h>
#include <string.h>

#define DIM 100

int main() {
    char str1[DIM];
    char str2[DIM];
    int i, j, len, flag;
    int cnt1, cnt2;

    printf("Inserisci la prima stringa: ");
    scanf("%s", str1);
    printf("Inserisci la seconda stringa: ");
    scanf("%s", str2);

    len = (int) strlen(str1);
    if (len != strlen(str2)) {
        printf("Le stringhe hanno lunghezza diversa.");
        return 0;
    }

    flag = 1;
    for (i = 0; i < len && flag; i++) {
        cnt1 = 0;
        cnt2 = 0;

        for (j = 0; j < len; j++) {
            if (str1[j] == str1[i]) {
                cnt1++;
            }
            if (str2[j] == str1[i]) {
                cnt2++;
            }
        }

        if (cnt1 != cnt2) {
            flag = 0;
        }
    }

    if (flag) {
        printf("Le parole sono anagrammi");
    } else {
        printf("Le parole NON sono anagrammi");
    }

    return 0;
}
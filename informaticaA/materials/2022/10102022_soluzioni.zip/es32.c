#include <stdio.h>
#include <string.h>

#define DIM 100

int main() {
    char str[DIM];
    int l, h, palindromo;

    printf("Inserisci la stringa: ");
    scanf("%s", str);

    l = 0;
    h = (int) strlen(str) - 1;
    palindromo = 1;

    while (h > l && palindromo) {
        if (str[l] != str[h]) {
            palindromo = 0;
        }
        l++;
        h--;
    }

    if (palindromo) {
        printf("La stringa è palindroma");
    } else {
        printf("La stringa NON è palindroma");
    }

    return 0;
}
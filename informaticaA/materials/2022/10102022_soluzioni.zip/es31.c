#include <stdio.h>

#define DIM 100

int main() {
    char str1[DIM], str2[DIM], str[2 * DIM];
    int i, j;

    printf("Inserisci la prima stringa: ");
    scanf("%s", str1);
    printf("Inserisci la seconda stringa: ");
    scanf("%s", str2);

    for (i = 0; str1[i] != '\0'; i++) {
        str[i] = str1[i];
    }

    for (j = 0; str2[j] != '\0'; j++) {
        str[i + j] = str2[j];
    }

    str[i+j] = '\0';
    printf("%s\n", str);

    return 0;
}

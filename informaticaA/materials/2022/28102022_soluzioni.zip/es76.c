#include <stdio.h>

#define N 3

int f(int [][N]);
void read_square_matrix(int [][N]);
void print_square_matrix(int [][N]);

int main() {
    int m[N][N];

    read_square_matrix(m);
    print_square_matrix(m);

    printf("Numero di elementi circondati da soli numeri pari: %d\n", f(m));

    return 0;
}

int f(int m[][N]) {
    int i, j, u, v, sum, cont = 0;

    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            sum = 0;
            for (u = i - 1; u <= i + 1; u++) {
                for (v = j - 1; v <= j + 1; v++) {
                    if (u != i || v != j) {
                        if (u < 0 || u >= N || v < 0 || v >= N) {
                            sum++;
                        } else if (m[u][v] % 2 == 0) {
                            sum++;
                        }
                    }
                }
            }
            if (sum == 8) {
                printf("(%d,%d) \n", i, j);
                cont++;
            }
        }
    }

    return cont;
}

void read_square_matrix(int m[][N]) {
    int r, c;
    printf("Inserire matrice: \n");
    for (r = 0; r < N; r++) {
        for (c = 0; c < N; c++) {
            scanf("%d", &m[r][c]);
        }
    }
    printf("\n");
}

void print_square_matrix(int m[][N]) {
    printf("Matrice:\n");
    int r, c;
    for (r = 0; r < N; r++) {
        for (c = 0; c < N; c++) {
            printf(" %d ", m[r][c]);
        }
        printf("\n");
    }
}

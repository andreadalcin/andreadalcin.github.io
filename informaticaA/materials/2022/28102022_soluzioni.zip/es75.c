#include <stdio.h>
#include <math.h>

#define N 9

void printv(int *, int);

void subpow(int *, int);

void update(int *, int *, int);

int main() {
    int v[N] = {1, 2, 3, 1, 2, 0, 2, 3, 0};
    int x = 3;

    printv(v, N);

    // Trova lunghezza del sotto-vettore
    int i, len = 0;
    for (i = x - 1; i < N; i++) {
        if (v[i] == 0) {
            len = i - (x - 1);
            break;
        }
    }

    subpow(&v[x - 1], len);
    printv(v, N);

    return 0;
}

void printv(int *v, int n) {
    int i;
    printf("[");
    for (i = 0; i < n; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", v[i]);
    }
    printf("]\n");
}

void subpow(int *v, int n) {
    int i;
    for (i = 0; i < n; i++) {
        v[i] = (int) pow(v[i], 2);
    }
}
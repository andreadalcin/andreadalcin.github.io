#include <stdio.h>

#define N 5

void f(int [], int *, int *);

void update(int *, int *, int);

int main() {
    int v[N] = {1, 2, 3, 4, 5};
    int even, odd;
    int *p_even, *p_odd;

    p_even = &even;
    p_odd = &odd;
    *p_even = 0;
    *p_odd = 0;

    f(v, p_even, p_odd);

    printf("Pari: %d, dispari: %d\n", *p_even, *p_odd);

    return 0;
}

void f(int *v, int *even, int *odd) {
    int i;
    for (i = 0; i < N; i++) {
        update(even, odd, v[i]);
    }
}

void update(int *even, int *odd, int num) {
    if (num % 2 == 0) {
        (*even)++;
    } else {
        (*odd)++;
    }
}
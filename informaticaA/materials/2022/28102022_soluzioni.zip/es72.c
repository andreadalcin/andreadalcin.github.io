#include <stdio.h>

#define N 6

void read_array(int *);
int f(const int *, int);

int main() {
    int v[N];
    int k, res;

    read_array(v);
    printf("Introdurre k:\n");
    scanf("%d", &k);

    res = f(v, k);
    printf("Numero di sequenza = %d\n", res);

    return 0;
}

void read_array(int *v) {
    int i;
    printf("Introdurre array di dimensione %d:\n", N);
    for (i = 0; i < N; i++) {
        scanf("%d", &v[i]);
    }
}

int f(const int *v, int k) {
    int i, len = 1, max_len = 1;
    for (i = 0; i < N - 1; i++) {
        if (v[i + 1] == v[i] + k || v[i + 1] == v[i] - k) {
            len++;
            if (len > max_len) {
                max_len = len;
            }
        } else {
            len = 1;
        }
    }
    return max_len;
}

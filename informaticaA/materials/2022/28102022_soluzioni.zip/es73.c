#include <stdio.h>
#include <math.h>

#define N 3

typedef struct {
    float re;
    float im;
} t_complex;


void read_complex(t_complex *);
float norm_complex(t_complex);
void sort_complex(t_complex *);


int main() {
    int i;
    t_complex v[N];

    read_complex(v);
    sort_complex(v);

    printf("Array riordinato: \n");
    for (i = 0; i < N; i++) {
        printf("[%d]: re=%.3f, im=%.3f, norm=%.3f\n", i + 1, v[i].re, v[i].im, norm_complex(v[i]));
    }

    return 0;
}


void read_complex(t_complex *v) {
    int i;
    for (i = 0; i < N; i++) {
        printf("Numero complesso #%d (di %d)\n", i + 1, N);
        printf("Re: ");
        scanf("%f", &v[i].re);
        printf("Im: ");
        scanf("%f", &v[i].im);
    }
}

float norm_complex(t_complex n) {
    return sqrt(pow(n.re, 2) + pow(n.im, 2));
}

void sort_complex(t_complex *v) {
    int i, j;
    t_complex temp;
    for (i = 0; i < N - 1; i++) {
        for (j = 0; j < N - i - 1; j++) {
            if (norm_complex(v[j]) > norm_complex(v[j + 1])) {
                temp = v[j];
                v[j] = v[j + 1];
                v[j + 1] = temp;
            }
        }
    }
}
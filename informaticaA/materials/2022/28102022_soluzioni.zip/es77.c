#include <stdio.h>

#define N 4

void f(int [][N]);

void print_square_matrix(int [][N]);

void copy(int *, int *);

int main() {
    int m[N][N] = {3, 1, 1, 2,
                   0, 0, 13, 0,
                   0, 7, 2, 3,
                   0, 5, 1, 6};
    print_square_matrix(m);

    f(m);
    print_square_matrix(m);

    return 0;
}

void f(int m[][N]) {
    int i;
    int aux[N];

    copy(m[N - 1], aux);

    for (i = N - 2; i >= 0; i--) {
        copy(m[i], m[i + 1]);
    }

    copy(aux, m[0]);
}

void copy(int *src, int *tgt) {
    int i;
    for (i = 0; i < N; i++) {
        tgt[i] = src[i];
    }
}

void print_square_matrix(int m[][N]) {
    printf("Matrice:\n");
    int r, c;
    for (r = 0; r < N; r++) {
        for (c = 0; c < N; c++) {
            printf(" %d ", m[r][c]);
        }
        printf("\n");
    }
}
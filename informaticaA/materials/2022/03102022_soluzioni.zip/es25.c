#include <stdio.h>

#define MAX_LEN 100

int main() {
    int i, j, n, temp;
    int arr[MAX_LEN];

    // Inserisci il numero di variabili da richiedere all'utente
    do {
        printf("Inserisci la lunghezza della sequenza (max %d): ", MAX_LEN);
        scanf("%d", &n);
    } while (n <= 0 || n > MAX_LEN);

    // Inserisci la sequenza di numeri nel vettore
    for (i = 0; i < n; i++) {
        printf("Inserisci un numero in posizione %d di %d: ", i + 1, n);
        scanf("%d", &arr[i]);
    }

    // Bubble sort!
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    // Stampa array
    for (i = 0; i < n; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", arr[i]);
    }

    return 0;
}
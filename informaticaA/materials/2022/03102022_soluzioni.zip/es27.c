#include <stdio.h>

#define MAX_LEN 100

int main() {
    int i, j, n, flag;
    int arr[MAX_LEN], prime[MAX_LEN];
    int len_prime = 0;

    // Inserisci il numero di variabili da richiedere all'utente
    do {
        printf("Inserisci la lunghezza della sequenza (max %d): ", MAX_LEN);
        scanf("%d", &n);
    } while (n <= 0 || n > MAX_LEN);

    // Inserisci la sequenza di numeri nel vettore
    for (i = 0; i < n; i++) {
        printf("Inserisci un numero in posizione %d di %d: ", i + 1, n);
        scanf("%d", &arr[i]);
    }

    for (i = 0; i < n; i++) {
        flag = 0;
        for (j = 2; j < arr[i] && !flag; j++) {
            /* Ottimizzazione: non considerare j se maggiore di arr[i] / 2
             * for (j = 2; j <= arr[i] / 2 && !flag; j++) {
             *      ...
             * }
             */
            if (arr[i] % j == 0) {
                flag = 1;
            }
        }

        if (!flag) {
            prime[len_prime] = arr[i];
            len_prime++;
        }
    }

    // Stampa l'array
    printf("La sequenza di soli numeri primi è: ");
    for (i = 0; i < len_prime; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", prime[i]);
    }

    return 0;
}
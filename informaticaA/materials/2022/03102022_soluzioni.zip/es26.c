#include <stdio.h>
#include <limits.h>

#define MAX_LEN 100

/*
 * Dato un array A d'interi di dimensione massima 100.
 * Scegli esattamente B elementi dall'estremo sinistro o destro dell'array A e ottieni la somma massima.
 * N.B. Puoi scegliere i primi B elementi o uno dall'inizio e B - 1 dalla fine e così via.
 * https://www.interviewbit.com/problems/pick-from-both-sides/
 */
int main() {
    int n, k, b, s;
    int i = 0;
    int m = INT_MIN;  // m è inizializzato come il numero minimo assegnabile a una variabile intera
    int arr[MAX_LEN];

    // Sposto dopo e metto in un do-while
    printf("Inserisci il numero di elementi da sommare: ");
    scanf("%d", &b);

    do {
        printf("Inserisci il numero di elementi nel vettore (max %d): ", MAX_LEN);
        scanf("%d", &n);
    } while (n <= 0 || n > MAX_LEN);

    if (b > n) {
        printf("Il numero di elementi da sommare è minore del numero di elementi del vettore.\n");
        return 1;   // togli e integra nel do-while
    }

    do {
        printf("Inserisci il numero %d di %d: ", i + 1, n);
        scanf("%d", &arr[i]);
        i++;
    } while (i < n);

    // B rappresenta il numero di elementi da sommare
    for (k = 0; k <= b; k++) {
        s = 0;
        for (i = 0; i < b; i++) {
            if (i < k) {
                s += arr[i];
            } else {
                s += arr[n-1 - i + k];
            }
        }

        if (s > m) {
            m = s;
        }
    }

    printf("La somma massima di %d elementi da sx o dx del vettore è: %d\n", b, m);

    return 0;
}

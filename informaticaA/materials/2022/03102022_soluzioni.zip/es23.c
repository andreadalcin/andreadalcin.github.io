#include <stdio.h>

#define MAX_LEN 100

int main() {
    int i, j, flag;
    int k = 0, n = 0;
    int arr[MAX_LEN], set[MAX_LEN];

    // Inserisci il numero di variabili da richiedere all'utente
    do {
        printf("Inserisci la lunghezza della sequenza (max %d): ", MAX_LEN);
        scanf("%d", &n);
    } while (n <= 0 || n > MAX_LEN);

    // Inserisci la sequenza di numeri nel vettore
    for (i = 0; i < n; i++) {
        printf("Inserisci un numero in posizione %d di %d: ", i + 1, n);
        scanf("%d", &arr[i]);
    }

    // Idea: dato a[i], se non esiste a[j] == a[i] con j < i, il numero a[i] non è stato ancora aggiunto all'insieme
    for (i = 0; i < n; i++) {
        flag = 1;   // flag indica che non esiste a[j] == a[i], j < i
        for (j = 0; j < i && flag; j++) {
            if (arr[i] == arr[j]) {
                // Abbiamo trovato un numero a[j] == a[i], j < i, quindi a[i] è stato già aggiunto all'insieme
                flag = 0;
            }
        }

        if (flag) {
            set[k] = arr[i];    // Aggiungi a[i] all'insieme se non esiste a[j] == a[i], j < i
            k++;
        }
    }

    /*
     * Vedi la versione alternativa di es23 (es23_alt.c) basata sulla ricerca in set
     */

    // Stampa insieme
    printf("L'insieme è: ");
    for (i = 0; i < k; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", set[i]);
    }

    return 0;
}

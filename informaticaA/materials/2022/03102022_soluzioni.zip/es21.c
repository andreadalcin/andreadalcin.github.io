#include <stdio.h>

#define MAX_LEN 100

int main() {
    int i, n, temp;
    int a[MAX_LEN];

    // Inserisci il numero di variabili da richiedere all'utente
    do {
        printf("Inserisci la lunghezza della sequenza (max %d): ", MAX_LEN);
        scanf("%d", &n);
    } while (n <= 0 || n > MAX_LEN);

    // Inserisci la sequenza di numeri nel vettore
    for (i = 0; i < n; i++) {
        printf("Inserisci un numero in posizione %d di %d: ", i + 1, n);
        scanf("%d", &a[i]);
    }

    // Inverti il vettore senza l'utilizzo di un vettore ausiliario
    for (i = 0; i < n / 2; i++) {
        temp = a[i];
        a[i] = a[n - 1 - i];
        a[n - 1 - i] = temp;
    }

    // Stampa il vettore invertito
    printf("Sequenza di numeri invertita: ");
    for (i = 0; i < n; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", a[i]);
    }

    return 0;   // Esci dal programma
}

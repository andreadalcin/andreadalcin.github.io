# Compaibile con sistemi operativi macOS e Linux
# Questo script compila tutti i programmi contemporaneamente da terminale usando cmake:
# https://en.wikipedia.org/wiki/CMake
# I programmi compilati saranno posizionati nella cartella 'build' e andranno eseguiti con il comando './es1' o './es2'
rm -r "build"
mkdir "build"
cd build || exit 1
cmake ..
make
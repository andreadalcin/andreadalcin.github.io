#include <stdio.h>
#include <math.h>

#define MAX_LEN 100

int main() {
    int n;
    int lista[MAX_LEN];
    int insieme[MAX_LEN];
    int lungh_ins;
    int i, j;
    int trovato;

    do {
        printf("Inserire il numero degli elementi da inserire: ");
        scanf("%d", &n);
    } while (n < 0 || n > MAX_LEN);

    for (i = 0; i < n; i++) {
        printf("Inserire il %do numero : ", i + 1);
        scanf("%d", &lista[i]);
    }

    lungh_ins = 1;
    insieme[0] = lista[0];
    for (i = 1; i < n; i++) {
        trovato = 0;

        // controlla di non avere già inserito numero nell'insieme
        for (j = 0; j < lungh_ins; j++)
            if (lista[i] == insieme[j])
                trovato = 1;

        if (!trovato) {
            insieme[lungh_ins] = lista[i];
            lungh_ins++;
        }
    }

    // stampa insieme
    printf("Insieme inserito: [ ");
    for (i = 0; i < lungh_ins; i++)
        printf("%d ", insieme[i]);
    printf("]\n");

}

#include <stdio.h>

#define MAX_LEN 100

int main() {
    int i, j, n;
    int a[MAX_LEN];

    // Inserisci il numero di variabili da richiedere all'utente
    do {
        printf("Inserisci la lunghezza della sequenza (max %d): ", MAX_LEN);
        scanf("%d", &n);
    } while (n <= 0 || n > MAX_LEN);

    // Inserisci la sequenza di numeri nel vettore
    for (i = 0; i < n; i++) {
        printf("Inserisci un numero in posizione %d di %d: ", i + 1, n);
        scanf("%d", &a[i]);
    }

    // Iterazione per tutte le coppie (ordinate) del vettore
    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            printf("> i = %d, j = %d\n", i, j);
            if (a[i] == a[j] * 2) {
                printf(">>> La coppia a[%d] = %d, a[%d] = %d soddisfa la condizione\n", i, a[i], j, a[j]);
            } else {
                printf(">>> La coppia a[%d] = %d, a[%d] = %d NON soddisfa la condizione\n", i, a[i], j, a[j]);
            }
        }
    }

    return 0;
}

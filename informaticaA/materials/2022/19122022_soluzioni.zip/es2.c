//
//  main.c
//  es_300821_02
//
//  Created by Alberto Marchesi on 10/12/21.
//

#include <stdio.h>
#include <stdlib.h>

typedef struct nd1{
    int valore;
    struct nd1* next;
} Nodo;
typedef Nodo* Lista;

typedef struct nd2{
    int valore;
    int quanteVolte;
    struct nd2* next;
} NodoRisultato;
typedef NodoRisultato* ListaRisultato;

Lista costruisci(void);
Lista InsInFondo(Lista lista, int elem);
void stampaLista(Lista lista);
void stampaListaRisultato(ListaRisultato risulato);

// TODO: implementazione funzione/i
ListaRisultato conteggiLista (Lista);
ListaRisultato InsInFondoListaRisultato (ListaRisultato, int, int);
int controllaPresenzaListaRisultato (ListaRisultato, int);

int main(){
    Lista lista;
    lista = costruisci();
    printf("Lista in input:\n");
    stampaLista(lista);

    ListaRisultato risultato;

    // TODO: chiamata funzione/i
    risultato = conteggiLista(lista);

    printf("Lista corretta:\n");
    stampaListaRisultato(risultato);

    return 0;
}

int controllaPresenzaListaRisultato (ListaRisultato risultato, int valore) {
    while (risultato != NULL) {
        if (risultato->valore == valore)
            return 1;
        risultato = risultato->next;
    }
    return 0;
}

ListaRisultato InsInFondoListaRisultato (ListaRisultato risultato, int valore, int quanteVolte){
    if(risultato==NULL){
        NodoRisultato* punt;
        punt = (NodoRisultato*) malloc(sizeof(NodoRisultato));
        punt->valore = valore;
        punt->quanteVolte = quanteVolte;
        punt->next   = NULL;
        return punt;
    } else {
        risultato->next = InsInFondoListaRisultato(risultato->next, valore, quanteVolte);
        return risultato;
    }
}

ListaRisultato conteggiLista (Lista lista) {
    Lista cur = NULL;
    ListaRisultato risultato = NULL;
    int count;
    while (lista != NULL) {
        if (controllaPresenzaListaRisultato(risultato, lista->valore) == 0) {
            count = 1;
            cur = lista->next;
            while (cur != NULL) {
                if (cur->valore == lista->valore)
                    count++;
                cur = cur->next;
            }
            risultato = InsInFondoListaRisultato(risultato, lista->valore, count);
        }
        lista = lista->next;
    }
    return risultato;
}

Lista costruisci(){
    Lista lista = NULL;
    lista = InsInFondo(lista, 3);
    lista = InsInFondo(lista, 5);
    lista = InsInFondo(lista, 1);
    lista = InsInFondo(lista, 4);
    lista = InsInFondo(lista, 3);
    lista = InsInFondo(lista, 4);
    lista = InsInFondo(lista, 3);
    lista = InsInFondo(lista, 4);
    lista = InsInFondo(lista, 1);
    lista = InsInFondo(lista, 8);
    return lista;
}

Lista InsInFondo(Lista lista, int elem){
    if(lista==NULL){
        Nodo* punt;
        punt = (Nodo*) malloc(sizeof(Nodo));
        punt->valore = elem;
        punt->next   = NULL;
        return punt;
    } else {
        lista->next = InsInFondo(lista->next, elem);
        return lista;
    }
}

void stampaLista(Lista lista){
    if(lista == NULL){
        printf("=||\n");
        return;
    } else {
        printf("%d -> ", lista->valore);
        stampaLista(lista->next);
    }
}

void stampaListaRisultato(ListaRisultato risultato){
    if(risultato == NULL){
        printf("=||\n");
        return;
    } else {
        printf("[%d (%d)] -> ", risultato->valore, risultato->quanteVolte);
        stampaListaRisultato(risultato->next);
    }
}

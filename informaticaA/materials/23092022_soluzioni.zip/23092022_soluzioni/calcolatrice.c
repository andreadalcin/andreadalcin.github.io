#include <stdio.h>

/*
 * Acquisisci un operatore (+, -, *, /) e due operandi dall'utente.
 * Esegui l'operazione specificata sui due operandi.
 * Stampa il risultato.
 */
int main() {
    char operatore;
    printf("Inserisci un operatore (+, -, *, /): ");
    scanf("%c", &operatore);

    double op1, op2;
    printf("Inserisci due operandi: ");
    scanf("%lf %lf", &op1, &op2);

    switch (operatore) {
        case '+':
            printf("%.1lf + %.1lf = %.1lf", op1, op2, op1 + op2);
            break;
        case '-':
            printf("%.1lf - %.1lf = %.1lf", op1, op2, op1 - op2);
            break;
        case '*':
            printf("%.1lf * %.1lf = %.1lf", op1, op2, op1 * op2);
            break;
        case '/':
            printf("%.1lf / %.1lf = %.1lf", op1, op2, op1 / op2);
            break;
        default:
            // L'operatore non è riconosciuto
            printf("Errore! L'operatore non è supportato.");
    }

    return 0;
}
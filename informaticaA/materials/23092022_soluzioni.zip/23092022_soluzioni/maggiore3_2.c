#include <stdio.h>

/*
 * Acquisici tre numeri dall'utente e identifica il massimo.
 * Stampa il numero in output.
 */
int main() {
    int n1, n2, n3;

    printf("Inserisci 3 numeri: ");
    scanf("%d %d %d", &n1, &n2, &n3);

    // If statement esterno
    if (n1 >= n2) {
        // if...else interno
        if (n1 >= n3)
            printf("%d è il massimo.", n1);
        else
            printf("%d è il massimo.", n3);
    }
    // else statement esterno
    else {
        // if...else interno
        if (n2 >= n3)
            printf("%d è il massimo.", n2);
        else
            printf("%d è il massimo.", n3);
    }

    return 0;
}
#include <math.h>
#include <stdio.h>

/*
 * Acquisisci tre coefficienti di un'equazione quadratica.
 * Risolvi l'equazione quadratica.
 * Stampa la/le radice/i in output.
 */
int main() {
    double a, b, c;
    printf("Inserisci i coefficienti a, b, c: ");
    scanf("%lf %lf %lf", &a, &b, &c);

    double discriminante = pow(b, 2) - 4 * a * c;   // pow(base, esponente) da <math.h>

    if (discriminante > 0) {
        // 2 radici reali
        double x1 = (-b + sqrt(discriminante)) / (2 * a);   // sqrt(numero) da <math.h>
        double x2 = (-b - sqrt(discriminante)) / (2 * a);
        printf("x1 = %.2lf, x2 = %.2lf", x1, x2);
    } else if (discriminante == 0) {
        // 1 radice reale
        double x = -b / (2 * a);
        printf("x1 = x2 = %.2lf", x);
    } else {
        // 2 radici complesse
        double reale = -b / (2 * a);
        double immaginaria = sqrt(-discriminante) / (2 * a);
        printf("x1 = %.2lf + %.2lfi, x2 = %.2lf - %.2lfi", reale, immaginaria, reale, immaginaria);
    }

    return 0;
}
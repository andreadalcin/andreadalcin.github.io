#include <stdio.h>

/*
 * Acquisisci un numero intero dall'utente e inverti le sue cifre.
 * Stampa il numero in output.
 */
int main() {
    int n, resto;
    int invertito = 0;

    printf("Inserisci un intero: ");
    scanf("%d", &n);

    while (n != 0) {
        resto = n % 10;
        invertito = invertito * 10 + resto;
        n /= 10;
    }

    printf("Numero invertito: %d", invertito);

    return 0;
}
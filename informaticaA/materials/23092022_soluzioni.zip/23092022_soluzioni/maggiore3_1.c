#include <stdio.h>

/*
 * Acquisici tre numeri dall'utente e identifica il massimo.
 * Stampa il numero in output.
 */
int main() {
    int n1, n2, n3;

    printf("Inserisci 3 numeri interi: ");
    scanf("%d %d %d", &n1, &n2, &n3);

    if (n1 >= n2 && n1 >= n3) {
        // Se n1 è maggiore di n2 e n3, n1 è il massimo
        printf("%d è il massimo.", n1);
    } else if (n2 >= n1 && n2 >= n3) {
        // Se n2 è maggiore di n1 e n3, n2 è il massimo
        printf("%d è il massimo.", n2);
    } else {
        // Se le condizioni precedenti non sono soddisfatte, n3 è il massimo
        printf("%d è il massimo.", n3);
    }

    return 0;
}
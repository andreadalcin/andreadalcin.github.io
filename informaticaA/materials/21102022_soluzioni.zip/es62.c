#include <stdio.h>
#include <math.h>

#define MAX_DEG 8

void print_poly(const int *poly, int deg) {
    for (int i = 0; i < deg; i++) {
        if (*(poly + i) != 0) {
            if (i > 0) {
                printf(" ");
            }

            if (*(poly + i) > 0) {
                printf("+");
            }
            printf("%d", *(poly + i));

            if (i > 0) {
                printf("x^%d", i);
            }
        }
    }
    printf("\n");
}

/*
 * Scrivere un programma che calcola il prodotto tra due polinomi di grado massimo 8. Il programma chiede prima il
 * grado ed i coefficienti di ciascuno dei due polinomi. In seguito esegue il prodotto polinomiale e visualizza i
 * coefficienti del polinomio risultato. Successivamente, chiede all’utente un intero x in cui calcolare il valore del
 * polinomio risultato, lo calcola, e lo stampa a video.
 */
int main() {
    int poly1[MAX_DEG + 1] = {0}, poly2[MAX_DEG + 1] = {0}, poly[MAX_DEG * MAX_DEG + 1] = {0};
    int deg1, deg2, i, j, x, sum;

    // Acquisisci gradi e coefficienti
    do {
        printf("Grado del I. polinomio: ");
        scanf("%d", &deg1);
    } while (deg1 < 0);

    for (i = 0; i <= deg1; i++) {
        if (i > 0) {
            printf("x^%d: ", i);
        } else {
            printf("Costante: ");
        }
        scanf("%d", (poly1 + i));
    }

    do {
        printf("Grado del II. polinomio: ");
        scanf("%d", &deg2);
    } while (deg2 < 0);

    for (i = 0; i <= deg2; i++) {
        if (i > 0) {
            printf("x^%d: ", i);
        } else {
            printf("Costante: ");
        }
        scanf("%d", (poly2 + i));
    }

    // Stampa polinomi in input
    print_poly(poly1, MAX_DEG);
    print_poly(poly2, MAX_DEG);

    // Calcola polinomio risultante
    for (i = 0; i <= deg1; i++) {
        for (j = 0; j <= deg2; j++) {
            *(poly + i + j) += *(poly1 + i) * *(poly2 + j);
        }
    }

    // Stampa polinomio risultante
    print_poly(poly, MAX_DEG * MAX_DEG);

    // Calcola il valore del polinomio
    printf("Inserisci il valore di x: ");
    scanf("%d", &x);

    sum = 0;
    for (i = 0; i < MAX_DEG * MAX_DEG; i++) {
        sum += *(poly + i) * (int) pow(x, i);
    }

    printf("Per x = %d, il polinomio ha valore: %d\n", x, sum);

    return 0;
}

#include <stdio.h>

#define LEN 3
#define N_MAX 100
#define MIN_DIV 2

/*
 * Scrivere un programma che legge un vettore contenente al massimo 100 interi positivi (di valore massimo 100) e stampa
 * a video l’istogramma dei divisori. L’istogramma deve avere tutti i valori da 2 al valore massimo immesso diviso per
 * 2. Il programma deve considerare solo i divisori propri, dove un divisore positivo di n diverso da n stesso è
 * chiamato divisore proprio.
 */
int main() {
    int arr[LEN] = {0}, div[N_MAX / 2] = {0};
    int i, j;

    // Acquisisci numeri dall'utente
    i = 0;
    while (i < LEN) {
        printf("Inserisci il numero %d di %d: ", i + 1, LEN);
        scanf("%d", (arr + i));
        if (*(arr + i) < 0) {
            continue;
        }
        i++;
    }

    // Calcolo istogramma divisori propri
    for (i = 0; i < LEN; i++) {
        for (j = MIN_DIV; j <= *(arr + i) / 2; j++) {
            if (*(arr + i) != j && *(arr + i) % j == 0) {
                *(div + j - MIN_DIV) += 1;
            }
        }
    }

    // Stampo l'istogramma dei divisori
    for (i = 0; i < N_MAX / 2; i++) {
        printf("%d\t|", i + MIN_DIV);
        for (j = 0; j < *(div + i); j++) {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}

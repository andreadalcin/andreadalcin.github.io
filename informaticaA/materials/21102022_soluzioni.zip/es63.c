#include <stdio.h>
#include <limits.h>

#define N 4

int main() {
    int mat[N][N] = {2, 1, 0, 5,
                     3, 4, 1, 6,
                     1, 0, 8, 1,
                     5, 1, 9, 7};
    int len, i, j, k;
    int *elem = NULL;

    /* Per tenere traccia della lunghezza massima */
    int max_len = INT_MIN;
    int *max_elem = NULL;

    /* Cerca lunghezza massima sulle righe */
    for (i = 0; i < N; i++) {
        len = 0;

        for (j = 0; j < N; j++) {
            if (elem == NULL || *elem != mat[i][j]) {
                len = 0;
                elem = &mat[i][j];
            }

            len++;

            if (len > max_len) {
                max_len = len;
                max_elem = &mat[i][j];
            }
        }
    }

    /* Cerca la lunghezza massima sulle colonne */
    for (j = 0; j < N; j++) {
        len = 0;

        for (i = 0; i < N; i++) {
            if (elem == NULL || *elem != mat[i][j]) {
                len = 0;
                elem = &mat[i][j];
            }

            len++;

            if (len > max_len) {
                max_len = len;
                max_elem = &mat[i][j];
            }
        }
    }

    /* Cerca la lunghezza massima sulla matrice triangolare bassa (diagonale principale compresa) */
    for (k = 0; k < N; k++) {
        len = 0;

        for (j = 0; j < N && k + j < N; j++) {
            if (elem == NULL || *elem != mat[k + j][j]) {
                len = 0;
                elem = &mat[k + j][j];
            }

            len++;

            if (len > max_len) {
                max_len = len;
                max_elem = &mat[k + j][j];
            }
        }
    }

    /* Cerca la lunghezza massima sulla matrice triangolare alta */
    for (k = 1; k < N; k++) {
        len = 0;

        for (i = 0; i < N && k + i < N; i++) {
            if (elem == NULL || *elem != mat[i][k + i]) {
                len = 0;
                elem = &mat[i][k + i];
            }

            len++;

            if (len > max_len) {
                max_len = len;
                max_elem = &mat[i][k + i];
            }
        }
    }


    if (max_elem != NULL) {
        printf("Lunghezza massima di %d elementi trovata per %d", max_len, *max_elem);
    } else {
        printf("Lunghezza massima non trovata");
    }

    return 0;
}
#include "helper.h"

#define N 3

int main() {
    int mat[N][N] = {0};
    int i = N - 1, j = (N + 1) / 2 - 1;
    int u, v;
    int n;

    for (n = 1; n <= N * N; n++) {
        mat[i][j] = n;

        u = (i + 1) % N;
        v = (j + 1) % N;

        if (mat[u][v] != 0) {
            u = i - 1;
            v = j;
            if (u < 0) {
                u += N;
            }
        }

        i = u;
        j = v;
    }

    /* Stampa la matrice */
    print_mat(mat[0], N, N);
}
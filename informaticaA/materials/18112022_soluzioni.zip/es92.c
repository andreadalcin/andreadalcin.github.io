#include <stdio.h>

int convert(int);

/**
 * Scrivere una funzione ricorsiva per convertire un intero dato in input nella sua codifica binaria (no CP2).
 */
int main() {
    int n = 16;

    int bin = convert(n);
    printf("%d", bin);

    return 0;
}


int convert(int n) {
    int q, r;
    if (n == 0) {
        return 0;
    }

    r = n % 2;
    q = n / 2;

    return convert(q) * 10 + r;
}
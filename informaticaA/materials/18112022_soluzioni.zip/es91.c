#include <stdio.h>

void recurse(int, int);

/**
 * Scrivere un programma che stampi i primi N numeri naturali usando una funzione ricorsiva.
 */
int main() {
    int n;
    printf("Inserisci N: ");
    scanf("%d", &n);

    recurse(n, 1);

    return 0;
}

void recurse(int n, int dep) {
    if (dep > n) {
        return;
    }

    printf("%d\n", dep);
    recurse(n, dep + 1);
}
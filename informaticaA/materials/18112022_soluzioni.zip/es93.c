#include <stdio.h>

#define N 6

void print_array(int *, int);
void tartaglia(int *, int, int);

/**
 * Scrivere un programma che stampa a video i valori del triangolo di tartaglia dato un ordine N
 */
int main() {
    int arr[N + 1] = {0};

    tartaglia(arr, 0, N);

    return 0;
}

void tartaglia(int *arr, int len, int order) {
    if (len > order) {
        return;
    }

    // Aggiungi un 1 alla fine della sequenza
    arr[len++] = 1;

    int tmp;
    int mem = arr[0];   // Ricordati del valore che hai sovrascritto

    for (int i = 1; i < len - 1; i++) {
        tmp = arr[i];
        arr[i] += mem;
        mem = tmp;
    }

    print_array(arr, len);

    // Funzione ricorsiva per la profondità successiva del triangolo
    tartaglia(arr, len, order);
}


void print_array(int *arr, int len) {
    for (int i = 0; i < len; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", arr[i]);
    }
    printf("\n");
}
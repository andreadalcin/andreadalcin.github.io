#include <stdio.h>
#include "limits.h"

#define N 100

int solve(int *, int *, int);
int solve_from_pose(int *, int *, int, int);

/**
 * Trova la più lunga sottosequenza crescente di un array A.
 * La sequenza non è necessariamente continua (si possono saltare elementi) o unica.
 * Ci interessa solo la lunghezza della sottosequenza
 */
int main() {
    int len = 16;
    int arr[N] = {0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15};
    int memo[N] = {0};

    // Inizializza array per memoization
    for (int i = 0; i < len; i++) {
        memo[i] = -1;
    }

    int length = solve(arr, memo, len);
    printf("Sotto-sequenza più lunga: %d", length);

    return 0;
}

int solve(int *arr, int *memo, int len) {
    int sub_longest = INT_MIN;
    int sub_length;

    for (int i = 0; i < len; i++) {
        sub_length = solve_from_pose(arr, memo, len, i);
        if (sub_length > sub_longest) {
            sub_longest = sub_length;
        }
    }

    return sub_longest;
}

int solve_from_pose(int *arr, int *memo, int len, int pos) {
    // Caso base: quando siamo oltre la fine del vettore
    if (pos > len) {
        return 0;
    }

    int sub_longest = 1;

    // Scorriamo tutti gli elementi successivi del vettore e calcoliamo le sotto-sequenze massime partendo da ciascun
    // elemento successivo
    for (int i = pos + 1; i < len; i++) {
        if (arr[i] > arr[pos]) {
            // Calcola le sotto-sequenze più lunghe solo se è necessario
            if (memo[i] < 0) {
                memo[i] = 1 + solve_from_pose(arr, memo, len, i);
            }

            // Aggiorna la sequenza massima se necessario
            if (memo[i] > sub_longest) {
                sub_longest = memo[i];
            }
        }
    }

    return sub_longest;
}
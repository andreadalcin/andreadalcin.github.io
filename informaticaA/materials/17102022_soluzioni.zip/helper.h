#include <stdio.h>

void print_vec(const int *vec, int len);

void print_mat(const int *mat, int rows, int cols);


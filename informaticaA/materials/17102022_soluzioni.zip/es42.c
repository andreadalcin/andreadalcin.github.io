#include <stdio.h>
#include "helper.h"

#define MAT_W 30
#define MAT_H 20
#define S 2

/*
 * Scrivere un programma che chiede all’utente di inserire una matrice di interi 20 × 30, poi esegue le seguenti operazioni:
 * 1. calcola quante sotto-matrici quadrate 2 × 2 hanno somma degli elementi pari a zero;
 * 2. calcola quante sotto-matrici quadrate di dimensione qualsiasi hanno somma degli ele-
menti pari a zero.
 */
int main() {
    int mat[MAT_H][MAT_W] = {0};
    int i, j, u, v;
    int sub_sum, cnt;

    // Acquisisci matrice
    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            printf("Inserisci l'elemento mat[%d, %d]: ", i, j);
            scanf("%d", &mat[i][j]);
        }
    }

    print_mat(mat[0], MAT_H, MAT_W);

    // Conta il numero di sotto-matrici con somma pari a 0
    cnt = 0;
    for (i = 0; i < MAT_H - S + 1; i++) {
        for (j = 0; j < MAT_W - S + 1; j++) {
            sub_sum = 0;
            for (u = i; u < i + S; u++) {
                for (v = j; v < j + S; v++) {
                    sub_sum += mat[u][v];
                }
            }
            if (sub_sum == 0) {
                cnt++;
            }
        }
    }

    printf("Numero di sotto-matrici: %d", cnt);
    return 0;
}
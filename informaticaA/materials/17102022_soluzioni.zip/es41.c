#include <stdio.h>
#include "helper.h"

#define MAT_W 30
#define MAT_H 20

/*
 * Scrivere un programma che chiede all’utente di inserire una matrice di interi 20 × 30,
 * poi (dopo aver terminato la fase di inserimento) esegue le seguenti operazioni:
 * 1. crea un vettore in cui ciascun elemento contiene il numero di elementi dispari in ciascuna riga della matrice;
 * 2. copia gli elementi dispari in una seconda matrice 20 × 30 senza lasciare buchi, se non in fondo.
 */
int main() {
    int mat[MAT_H][MAT_W] = {0};
    int dst[MAT_H][MAT_W] = {0};
    int odd[MAT_H] = {0};
    int i, j, u, v;

    // Acquisisci matrice
    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            printf("Inserisci l'elemento mat[%d, %d]: ", i, j);
            scanf("%d", &mat[i][j]);
        }
    }

    printf("Matrice di input:\n");
    print_mat(mat[0], MAT_H, MAT_W);

    // 1. Crea un vettore
    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            if (mat[i][j] % 2 != 0) {
                odd[i]++;
            }
        }
    }

    printf("Conto numeri dispari per riga:\n");
    print_vec(odd, MAT_H);
    printf("\n");

    // Copia gli elementi dispari in un'altra matrice
    u = 0;
    v = 0;
    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            if (mat[i][j] % 2 != 0) {
                if (v >= MAT_W) {
                    v = 0;
                    u++;
                }
                dst[u][v] = mat[i][j];
                v++;
            }
        }
    }

    printf("Matrice di numeri dispari:\n");
    print_mat(dst[0], MAT_H, MAT_W);

    return 0;
}

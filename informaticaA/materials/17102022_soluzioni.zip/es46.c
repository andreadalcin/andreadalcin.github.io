#include <stdio.h>
#include <limits.h>
#include <math.h>

#include "helper.h"

#define PI 3.14159265
#define N 3

/*
 * Scrivere un programma che chiede all’utente di inserire una matrice di NxN interi e un angolo multiplo di 90° (es.
 * 90°, 180°, 270°). Ruota la matrice NxN dell'angolo specificato dall'utente.
 */
int main() {
    int i, j, u, v, a, min_u, min_v;
    double sin_a, cos_a;
    int mat[N][N] = {0}, dst[N][N] = {0}, uv[N][N][2] = {0};

    // Acquisisci matrice
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            printf("Inserisci l'elemento mat[%d, %d]: ", i, j);
            scanf("%d", &mat[i][j]);
        }
    }

    printf("Matrice di input:\n");
    print_mat(mat[0], N, N);

    // Acquisisci angolo
    do {
        printf("Angolo di rotazione della matrice: ");
        scanf("%d", &a);
    } while (a % 90 != 0);

    // =================================================================================================================
    // Ruota la matrice
    min_u = INT_MAX;
    min_v = INT_MAX;
    sin_a = sin(a * PI / 180);
    cos_a = cos(a * PI / 180);

    // Applica trasformazione alle coordinate [i,j]
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            // Trasformazione di coordinate
            u = round(cos_a * i - sin_a * j);
            v = round(sin_a * i + cos_a * j);

            uv[i][j][0] = u;
            uv[i][j][1] = v;

            if (u < min_u) min_u = u;
            if (v < min_v) min_v = v;
        }
    }

    // Normalizza le coordinate tra [0, N]
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            u = uv[i][j][0] - min_u;
            v = uv[i][j][1] - min_v;
            dst[u][v] = mat[i][j];
        }
    }

    printf("Matrice di output:\n");
    print_mat(dst[0], N, N);

    return 0;
}

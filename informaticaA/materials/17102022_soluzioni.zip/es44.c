#include <stdio.h>
#include "helper.h"

#define N 3

/*
 * Scrivere un programma che stampa una matrice secondo un ordinamento a spirale.
 */
int main() {
    int mat[N][N] = {0};
    int i, j, k;

    // Acquisisci matrice
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            printf("Inserisci l'elemento mat[%d, %d]: ", i, j);
            scanf("%d", &mat[i][j]);
        }
    }

    print_mat(mat[0], N, N);

    for (k = 0; k < N / 2 + 1; k++) {
        for (i = k; i < N - k; i++) {
            printf("%d ", mat[k][i]);
        }
        for (i = k + 1; i < N - k; i++) {
            printf("%d ", mat[i][N - 1 - k]);
        }
        for (i = N - 2 - k; i >= k; i--) {
            printf("%d ", mat[N - 1 - k][i]);
        }
        for (i = N - 2 - k; i >= k + 1; i--) {
            printf("%d ", mat[i][k]);
        }
    }

    return 0;
}
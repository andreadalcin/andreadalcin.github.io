#include <stdio.h>
#include <limits.h>
#include "helper.h"

#define MAT_W 30
#define MAT_H 20

/*
 * Scrivere un programma che chiede all’utente di inserire una matrice di interi 20 × 30.
 * Per ogni possibile dimensione B di sottomatrice quadrata, stampa un singolo intero che denota la somma massima di
 * una sottomatrice di dimensione B x B.
 */
int main() {
    int mat[MAT_H][MAT_W] = {0};
    int i, j, u, v, b, s, max_s, n;

    // Acquisisci matrice
    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            printf("Inserisci l'elemento mat[%d, %d]: ", i, j);
            scanf("%d", &mat[i][j]);
        }
    }

    printf("Matrice di input:\n");
    print_mat(mat[0], MAT_H, MAT_W);

    // Trova la dimensione minima
    if (MAT_H < MAT_W) {
        n = MAT_H;
    } else {
        n = MAT_W;
    }

    // Per ogni dimensione di sotto-matrice b <= n trova la massima somma ottenibile
    for (b = 1; b <= n; b++) {
        max_s = INT_MIN;

        for (i = 0; i <= MAT_H - b; i++) {
            for (j = 0; j <= MAT_W - b; j++) {
                s = 0;
                for (u = i; u < i + b; u++) {
                    for (v = j; v < j + b; v++) {
                        s += mat[u][v];
                    }
                }

                if (s > max_s) {
                    max_s = s;
                }
            }
        }

        printf("Le sottomatrici di dimensione B = %d hanno somma massima pari a: %d\n", b, max_s);
    }

    return 0;
}

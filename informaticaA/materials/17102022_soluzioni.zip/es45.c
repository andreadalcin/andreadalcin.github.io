#include <stdio.h>
#include "helper.h"

#define MAT_W 30
#define MAT_H 20

/*
 * Scrivere un programma che chiede all’utente di inserire una matrice di interi 20 × 30.
 * Se un elemento è pari a 0, imposta tutta la sua riga e colonna a 0.
 */
int main() {
    int mat[MAT_H][MAT_W] = {0};
    int mask[MAT_H][MAT_W] = {0};
    int i, j, k;

    // Acquisisci matrice
    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            printf("Inserisci l'elemento mat[%d, %d]: ", i, j);
            scanf("%d", &mat[i][j]);
        }
    }

    printf("Matrice di input:\n");
    print_mat(mat[0], MAT_H, MAT_W);

    // Trova quali posizioni sono zeri
    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            if (mat[i][j] == 0) {
                // Riga dst[i][*] a zero
                for (k = 0; k < MAT_W; k++) {
                    mask[i][k] = 1;
                }
                // Colonna dst[*][j] a zero
                for (k = 0; k < MAT_H; k++) {
                    mask[k][j] = 1;
                }
            }
        }
    }

    // Maschera la matrice di input
    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            if (mask[i][j] != 0) {
                mat[i][j] = 0;
            }
        }
    }

    printf("Matrice di output:\n");
    print_mat(mat[0], MAT_H, MAT_W);

    return 0;
}

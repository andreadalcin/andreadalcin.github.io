#include <stdio.h>
#include "helper.h"

#define MAT_W 30
#define MAT_H 20

/*
 * Scrivere un programma che esegue un inserimento controllato di una matrice.
 * In particolare, il programma deve controllare che il valore corrente non sia gia` stato inserito dall’utente
 * in precedenza, e nel caso non inserirlo.
 */
int main() {
    int mat[MAT_H][MAT_W] = {0};
    int i, j, k, u, v, num, flag;

    for (i = 0; i < MAT_H; i++) {
        for (j = 0; j < MAT_W; j++) {
            do {
                printf("Inserisci l'elemento mat[%d, %d]: ", i, j);
                scanf("%d", &num);

                flag = -1;
                for (k = 0; k < (i * MAT_W + j) && flag < 0; k++) {
                    u = k / MAT_W;
                    v = k % MAT_W;

                    if (mat[u][v] == num) {
                        flag = k;
                    }
                }

                if (flag < 0) {
                    mat[i][j] = num;
                } else {
                    printf("Il numero %d è già stato inserito in mat[%d, %d]\n", num, flag / MAT_W, flag % MAT_W);
                }
            } while (flag >= 0);
        }
    }

    printf("Matrice:\n");
    print_mat(mat[0], MAT_H, MAT_W);
    return 0;
}
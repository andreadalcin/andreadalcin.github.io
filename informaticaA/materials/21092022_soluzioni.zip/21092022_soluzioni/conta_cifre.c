#include <stdio.h>

int main() {
    int n, m;
    int i = 0;

    do {
        printf("inserisci n positivo: ");
        // N.B. A lezione abbiamo visto anche il caso n negativo
        scanf("%d", &n);
        // Attenzione ai numeri maggiori o uguali di (2^31 - 1)
        // Una variabile int (32 bit) può contenere numeri nell'intervallo [-2^31; 2^31-1]
        // https://it.wikipedia.org/wiki/2147483647
    } while (n < 0);
    m = n;

    do {
        n = n / 10;
        i++;
    } while (n > 0);    // per n negativo la condizione è n != 0

    if (i > 1) {
        printf("%d ha %d cifre", m, i);
    } else {
        printf("%d ha %d cifra", m, i);
    }

    return 0;
}

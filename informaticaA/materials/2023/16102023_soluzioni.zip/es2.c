#include "stdio.h"
#include "math.h"

#define X 3
#define Y 4

int main() {
    int i, j, u, v, d, min_dim, sum, cnt = 0;
    int mat[X][Y] = {{-1, 0,  3,   4},
                     {1,  0,  -12, -11},
                     {9,  10, 11,  12}};

    // Trovare la dimensione minima della matrice.
    if (X < Y) {
        min_dim = X;
    } else {
        min_dim = Y;
    }

    // Ciclo for per determinare dimensione sotto-matrice.
    for (d = 1; d <= min_dim; d++) {
        // Ciclo for per determinare il primo elemento (in alto a sinistra) della sotto-matrice.
        for (i = 0; i < X - d + 1; i++) {
            for (j = 0; j < Y - d + 1; j++) {
                // Reset somma per la sotto-matrice con primo elemento (i,j)
                sum = 0;

                // Ciclo for per sommare gli elementi della sotto-matrice.
                for (u = i; u < i + d; u++) {
                    for (v = j; v < j + d; v++) {
                        sum += mat[u][v];
                    }
                }

                if (sum == 0) {
                    cnt++;
                }
            }
        }
    }

    printf("The number of zero-sum sub-matrices is: %d", cnt);

    return 0;
}
#include <stdio.h>

#define X 3
#define Y 4

void printVec(int[X]);
void printMatrix(int[X][Y]);

int main() {
    int mat[X][Y] = {{1, 11, 3,  4},
                     {5, 6,  7,  8},
                     {9, 10, 11, 12}};
    int des[X][Y];
    int odd[X];
    int i, j, u = 0, v = 0;

    printf("The input matrix is:\n");
    printMatrix(mat);

    // -----------------------------------------------------------------------------------------------------------------
    // Inizializzare il vettore.
    for (i = 0; i < X; ++i) {
        odd[i] = 0;
    }

    // Scorrere la matrice per righe e contare il numero di elementi dispari su tutte le colonne.
    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            // Verificare se l'elemento all'indice (i,j) è dispari.
            if (mat[i][j] % 2 != 0) {
                odd[i]++;
            }
        }
    }

    printf("The number of per-row odd numbers is: ");
    printVec(odd);

    // -----------------------------------------------------------------------------------------------------------------

    // Inizializzare la matrice di destinazione a -1.
    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            des[i][j] = -1;
        }
    }

    // Copiare nella matrice di destinazione gli elementi dispari della matrice iniziale.
    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            if (mat[i][j] % 2 != 0) {
                des[u][v] = mat[i][j];
                if (v + 1 == Y) {
                    v = 0;
                    u++;
                } else {
                    v++;
                }
            }
        }
    }

    printf("The matrix of only odd numbers is: \n");
    printMatrix(des);

    return 0;
}

/* Non abbiamo ancora fatto le funzioni */
void printVec(int vec[X]) {
    printf("[");
    for (int i = 0; i < X; ++i) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", vec[i]);
    }
    printf("]\n");
}

void printMatrix(int mat[X][Y]) {
    printf("[");
    for (int i = 0; i < X; ++i) {
        printf("[");
        for (int j = 0; j < Y; ++j) {
            if (j > 0) {
                printf(", ");
            }
            printf("%d", mat[i][j]);
        }
        printf("]");
        if (i + 1 < X) {
            printf("\n");
        }
    }
    printf("]\n");
}
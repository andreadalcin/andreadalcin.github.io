#include "stdio.h"

#define X 3
#define Y 3
#define Z 3

void printTensor(int ten[X][Y][Z]);

int main() {
    int i, j, k, u, v, z;
    int ten[X][Y][Z] = {{{1, 0, 3}, {4, 5, 6}, {5, 6, 7}},
                        {{1, 2, 3}, {4, 5, 6}, {5, 6, 7}},
                        {{1, 2, 3}, {4, 5, 6}, {5, 0, 7}}
    };
    int des[X][Y][Z];

    printf("The first tensor is:\n");
    printTensor(ten);

    // Copiare il primo tensore in un secondo tensore.
    for (i = 0; i < X; ++i) {
        for (j = 0; j < Y; ++j) {
            for (k = 0; k < Z; ++k) {
                des[i][j][k] = ten[i][j][k];
            }
        }
    }

    printf("The second tensor is:\n");
    printTensor(des);

    // Iterazione sul primo tensore per individuare elementi pari a zero.
    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            for (k = 0; k < Z; k++) {
                // Se l'elemento all'indice (i,j,k) è uguale a zero.
                if (ten[i][j][k] == 0) {
                    // Azzerare l'asse (i,j,k) nel secondo tensore. Questo si ottiene fissando due assi su tre e
                    // facendo variare la coordinata lungo l'asse variabile.

                    // X: variabile, YZ: fissi
                    for (u = 0; u < X; u++) {
                        des[u][j][k] = 0;
                    }

                    // Y: variabile, XZ: fissi
                    for (v = 0; v < Y; v++) {
                        des[i][v][k] = 0;
                    }

                    // Z variabile, XY: fissi
                    for (z = 0; z < Z; z++) {
                        des[i][j][z] = 0;
                    }
                }
            }
        }
    }

    printf("The tensor with its axes zeroed out is:\n");
    printTensor(des);

    return 0;
}

/* Non abbiamo ancora fatto le funzioni */
void printTensor(int ten[X][Y][Z]) {
    // Seguiamo la convenzione secondo cui il tensore viene stampato nell'ordine degli assi (X -> Y -> Z).
    printf("[");
    for (int k = 0; k < Z; ++k) {
        printf("[");
        for (int j = 0; j < Y; ++j) {
            printf("[");
            for (int i = 0; i < X; ++i) {
                if (i > 0) {
                    printf(", ");
                }
                printf("%d", ten[i][j][k]);
            }
            printf("]");
            if (j + 1 < Y) {
                printf(",\n");
            }
        }
        printf("]");
        if (k + 1 < Z) {
            printf(",\n");
        }
    }
    printf("]\n");
}
#include "stdio.h"

#define X 3
#define Y 4

void printMatrix(int[X][Y]);

int main() {
    int mat[X][Y];
    int i, j, k, u, v, tmp, in_mat, cnt = 0;

    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            do {
                // Acquisire valore da utente in variabile temporanea.
                printf("Insert value in matrix at index (%d, %d): ", i, j);
                scanf("%d", &tmp);

                // Loop per controllare se l'elemento è già presente all'interno della matrice.
                // La variabile 'cnt' rappresenta il numero di valori già salvati all'interno della matrice.
                in_mat = 0;
                for (k = 0; k < cnt && in_mat == 0; k++) {
                    // Conversione da coordinate 1D (k) in coordinate 2D (u, v) per accedere alla matrice.
                    u = k / Y;
                    v = k % Y;
                    // Controllare se il valore temporaneo è presente nella matrice all'indice (u,v).
                    if (mat[u][v] == tmp) {
                        in_mat = 1;
                    }
                }

                if (in_mat == 0) {
                    printf("The matrix does not contain the provided value. Moving forward.\n");
                    mat[i][j] = tmp;
                    cnt++;
                } else {
                    printf("The matrix already contains the provided value. Try again.\n");
                }
            } while (in_mat == 1);
        }
    }

    printf("The matrix provided by the user is:\n");
    printMatrix(mat);

    return 0;
}

/* Non abbiamo ancora fatto le funzioni */
void printMatrix(int mat[X][Y]) {
    printf("[");
    for (int i = 0; i < X; ++i) {
        printf("[");
        for (int j = 0; j < Y; ++j) {
            if (j > 0) {
                printf(", ");
            }
            printf("%d", mat[i][j]);
        }
        printf("]");
        if (i + 1 < X) {
            printf("\n");
        }
    }
    printf("]\n");
}
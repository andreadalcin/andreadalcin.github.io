#include <stdio.h>
#include "string.h"
#include "limits.h"

#define N_VEICOLI 10000

typedef struct {
    char targa[7 + 1];
    char marca[15 + 1];
    char modello[20 + 1];
    int cc;
    int potenza;
    char categoria[16 + 1];
} motoveicolo_t;

typedef struct {
    char nome[30 + 1];
    char cognome[40 + 1];
    char cf[16 + 1];
} proprietario_t;

typedef struct {
    motoveicolo_t motoveicolo;
    proprietario_t proprietario;
} voce_t;

typedef voce_t pra_t[N_VEICOLI];

int main() {
    pra_t pra;
    int n_voci = 10;    // Dimensione effettiva del vettore, da modificare in base a quante entry inserite in pra.

    // -----------------------------------------------------------------------------------------------------------------
    int i, j, sum_cc;
    int max_cc = INT_MIN;
    proprietario_t max_pr;

    for (i = 0; i < n_voci; i++) {
        if (pra[i].motoveicolo.cc > max_cc) {
            max_cc = pra[i].motoveicolo.cc;
            max_pr = pra[i].proprietario;
        }
    }

    printf("Il codice fiscale del proprietario con la cilindrata massima è: %s", max_pr.cf);

    // -----------------------------------------------------------------------------------------------------------------
    max_cc = INT_MIN;

    for (i = 0; i < n_voci; i++) {
        sum_cc = 0;

        for (j = 0; j < n_voci; j++) {
            if (strcmp(pra[i].proprietario.cf, pra[j].proprietario.cf) == 0) {
                sum_cc += pra[j].motoveicolo.cc;
            }
        }

        if (sum_cc > max_cc) {
            max_cc = sum_cc;
            max_pr = pra[i].proprietario;
        }
    }

    printf("Il codice fiscale del proprietario con la cilindrata massima è: %s", max_pr.cf);

    return 0;
}

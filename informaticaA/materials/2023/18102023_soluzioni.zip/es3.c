#include <stdio.h>
#include "string.h"
#include "limits.h"

#define N_PIANI 20
#define N_UFFICI 40

typedef struct {
    char nome[20], cognome[20];
    int stipendio;
    int cat;
} Impiegato;

typedef struct {
    int superficie;
    char esp[20];
    Impiegato occupante;
} Ufficio;

int main() {
    int i, j, k, u, found;
    Ufficio torre[N_PIANI][N_UFFICI];
    Ufficio uff_cat5[N_PIANI * N_UFFICI];
    Impiegato cat5[N_PIANI * N_UFFICI];

    // -----------------------------------------------------------------------------------------------------------------
    strcpy(torre[5][20].esp, "sud");
    strcpy(torre[5][20].occupante.nome, "Giacomo");
    strcpy(torre[5][20].occupante.cognome, "Boracchi");
    torre[5][20].occupante.cat = 5;

    strcpy(torre[3][15].esp, "sud-est");
    strcpy(torre[3][15].occupante.nome, "Albus");
    strcpy(torre[3][15].occupante.cognome, "Silente");
    torre[3][15].occupante.cat = 5;

    strcpy(torre[8][33].esp, "nord");
    strcpy(torre[8][33].occupante.nome, "Severus");
    strcpy(torre[8][33].occupante.cognome, "Piton");
    torre[8][33].occupante.cat = 4;

    // -----------------------------------------------------------------------------------------------------------------
    for (i = 0; i < N_PIANI; i++) {
        for (j = 0; j < N_UFFICI; j++) {
            if ((strcmp(torre[i][j].esp, "sud") == 0 || strcmp(torre[i][j].esp, "sud-est") == 0)
                && torre[i][j].superficie >= 20 && torre[i][j].superficie <= 30) {
                printf("Cognome: %s\n", torre[i][j].occupante.cognome);
                printf("Stipendio: %d\n", torre[i][j].occupante.stipendio);
                printf("Categoria: %d\n", torre[i][j].occupante.cat);
            }
        }
    }

    // -----------------------------------------------------------------------------------------------------------------
    for (i = 0; i < N_PIANI; i++) {
        found = 0;
        for (j = 0; j < N_UFFICI && found == 0; j++) {
            if (strcmp(torre[i][j].esp, "nord") == 0) {
                found = 1;
            }
        }
        if (found == 0) {
            printf("Questo piano non ha uffici esposti a nord: %d\n", i + 1);
        }
    }

    // -----------------------------------------------------------------------------------------------------------------
    found = 0;

    for (i = 0; i < N_PIANI && found == 0; i++) {
        for (j = 0; j < N_UFFICI && found == 0; j++) {
            if (strcmp(torre[i][j].occupante.nome, "Giacomo") == 0
                && strcmp(torre[i][j].occupante.cognome, "Boracchi") == 0) {
                found = 1;
            }
        }
    }

    // A lezione avevo inserito un +1 per (i,j). Mi sono scordato che con la variabile di flag avviene comunque
    // l'incremento dei contatori e quindi non serve aggiungere +1 per compensare al fatto che il primo indice di piani
    // e uffici è 0.
    printf("Giacomo Boracchi si trova al piano %d nell'ufficio %d\n", i, j);

    // -----------------------------------------------------------------------------------------------------------------
    k = 0;
    for (i = 0; i < N_PIANI; i++) {
        for (j = 0; j < N_UFFICI; j++) {
            if (torre[i][j].occupante.cat == 5) {
                uff_cat5[k] = torre[i][j];
                k++;
            }
        }
    }

    printf("Il numero di uffici occupati da impiegati di categoria 5 è: %d\n", k);

    // -----------------------------------------------------------------------------------------------------------------
    k = 0;
    for (i = 0; i < N_PIANI; i++) {
        for (j = 0; j < N_UFFICI; j++) {
            if (torre[i][j].occupante.cat == 5) {
                found = 0;
                for (u = 0; u < k && found == 0; u++) {
                    if (strcmp(torre[i][j].occupante.nome, cat5[u].nome) == 0
                        && strcmp(torre[i][j].occupante.cognome, cat5[u].cognome) == 0) {
                        found = 1;
                    }
                }
                if (found == 0) {
                    cat5[k] = torre[i][j].occupante;
                    k++;
                }
            }
        }
    }

    printf("Il numero di impiegati di categoria 5 è: %d\n", k);

    return 0;
}

#include <stdio.h>
#include "string.h"

#define N_STR 100
#define N_POKEMON 151

typedef struct {
    char name[N_STR];
    char type[N_STR];
    int n_abilities;
    char abilities[2][N_STR];
} pokemon_t;

typedef pokemon_t pokedex_t[N_POKEMON];

int main() {
    int i, j, k;
    pokedex_t pokedex;
    pokemon_t fire[N_POKEMON];
    pokemon_t statico[N_POKEMON];

    // -----------------------------------------------------------------------------------------------------------------
    for (i = 0; i < N_POKEMON; i++) {
        pokedex[i].n_abilities = 0;
    }

    pokemon_t pikachu;
    strcpy(pikachu.name, "Pikachu");
    strcpy(pikachu.type, "Elettro");
    pikachu.n_abilities = 2;
    strcpy(pikachu.abilities[0], "Statico");
    strcpy(pikachu.abilities[1], "Parafulmine");
    pokedex[24] = pikachu;

    pokemon_t charmander;
    strcpy(charmander.name, "Charmander");
    strcpy(charmander.type, "Fuoco");
    charmander.n_abilities = 2;
    strcpy(charmander.abilities[0], "Aiutofuoco");
    strcpy(charmander.abilities[1], "Solarpotere");
    pokedex[3] = charmander;

    // -----------------------------------------------------------------------------------------------------------------
    printf("Il Pokemon numero 25 è: %s\n", pokedex[25 - 1].name);

    // -----------------------------------------------------------------------------------------------------------------
    for (i = 0; i < N_POKEMON; i++) {
        if (strcmp(pokedex[i].name, "Charmander") == 0) {
            break;
        }
    }
    printf("L'indice di Charmander è: %d\n", i + 1);

    // -----------------------------------------------------------------------------------------------------------------
    j = 0;
    for (i = 0; i < N_POKEMON; i++) {
        if (strcmp(pokedex[i].type, "Fuoco") == 0) {
            fire[j] = pokedex[i];
            j++;
        }
    }
    printf("Il numero di Pokemon di tipo Fuoco è: %d", j);

    // -----------------------------------------------------------------------------------------------------------------
    k = 0;
    for (i = 0; i < N_POKEMON; i++) {
        for (j = 0; j < pokedex[i].n_abilities; j++) {
            if (strcmp(pokedex[i].abilities[j], "Statico") == 0) {
                statico[k] = pokedex[i];
                k++;
                break;
            }
        }
    }

    return 0;
}

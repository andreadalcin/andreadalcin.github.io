#include "stdio.h"

int main() {
    int i, n, is_prime = 1;

    printf("Inserire un numero: ");
    scanf("%d", &n);

    // Gestione dei casi limite.
    if (n <= 1) {
        printf("Il numero inserito non è supportato.");
        return 0;
    }

    if (n <= 2) {
        printf("Il numero inserito è primo.");
        return 0;
    }

    // Controllo numero primo.
    for (i = 2; i <= n / 2 && is_prime == 1; i++) {
        if (n % i == 0) {
            is_prime = 0;
        }
    }

    /* In alternativa è possibile usare break per uscire dal loop.
    for (i = 2; i < n / 2; i++) {
        if (n % i == 0) {
            is_prime = 0;
            break;
        }
    }
    */

    // Stampa l'esito del controllo.
    printf(is_prime ? "Il numero inserito è primo" : "Il numero inserito non è primo");

    return 0;
}
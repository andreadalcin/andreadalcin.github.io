#define N 100

#include<stdio.h>

int main() {
    int r, n8 = 0, n4 = 0, n2 = 0, n, i = 0;
    int vet[N];

    do {
        printf("\ninserire un numero: ");
        scanf("%d", &vet[i]);
        if (vet[i] > 0) {
            r = vet[i] % 8;
            switch (r) {
                // il numero è divisibile per 8
                case 0:
                    n8++;
                case 4:
                    n4++;
                case 2:
                    n2++;
                    break;
                case 6:
                    n2++;
            }
        }
        i++;
    } while (vet[i - 1] != 0 && i < N);
    n = i;
    printf("\n%d numeri,\nmult. di 8:%d \nmult. di 4:%d\nmult. di 2:%d\n\n", n, n8, n4, n2);
    return 0;
}

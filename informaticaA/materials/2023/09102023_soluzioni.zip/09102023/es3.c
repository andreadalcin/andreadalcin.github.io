#include "stdio.h"

#define N 100

int main() {
    int A[N], B[N];
    int i, n = 0;

    // Acquisire una sequenza di numeri dall'utente.
    while (n < N) {
        printf("\nInserire un numero: ");
        scanf("%d", &A[n]);
        if (A[n] < 0) {
            break;
        }
        n++;
    }

    if (n == 0) {
        printf("La sequenza inserita è vuota.");
        return 0;
    }

    // Invertire la sequenza.
    for (i = 0; i < n; i++) {
        B[n - 1 - i] = A[i];
    }

    // Stampare la sequenza.
    printf("Sequenza invertita: ");
    for (i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", B[i]);
    }

    return 0;
}
#include "stdio.h"

#define N 100

int main() {
    char str[N];
    int i, length, is_palindrome = 1;

    printf("Inserire una stringa: ");
    // scanf() non gestisce whitespace e newline.
    // scanf("%s", str);
    // fgets() legge un massimo di N caratteri da terminale (consigliato). fgets() legge anche il newline, che sarà
    // presente all'interno della stringa.
    fgets(str, N, stdin);

    // Calcola la lunghezza della stringa.
    for (length = 0; str[length] != '\0'; length++) {
    }

    // In alternativa:
    // #include "string.h"
    // length = strlen(str);

    // Rimozione del newline in fondo alla stringa (versione semplice)
    str[length - 1] = '\0';
    length -= 1;

    // Rimozione del newline in fondo alla stringa (versione corretta)
    // str[strcspn(str, "\n")] = '\0';

    // -----------------------------------------------------------------------------------------------------------------
    // Verifico che la stringa sia palindroma. Come da esercitazione:
    for (i = 0; i < length && is_palindrome == 1; i++) {
        if (str[i] != str[length - i - 1]) {
            is_palindrome = 0;
        }
    }

    printf(is_palindrome ? "La stringa è palindroma" : "La stringa NON è palindroma");
    return 0;
}
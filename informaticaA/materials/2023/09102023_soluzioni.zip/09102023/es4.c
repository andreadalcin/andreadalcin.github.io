#include "stdio.h"

#define N 100

int main() {
    int A[N];
    int i, j, n = 0;

    // Acquisire una sequenza di numeri dall'utente.
    while (n < N) {
        printf("\nInserire un numero: ");
        scanf("%d", &A[n]);
        if (A[n] < 0) {
            break;
        }
        n++;
    }

    // Stampare le coppie per cui la condizione è verificata.
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            // Se i == j, gli indici si riferiscono allo stesso elemento del vettore.
            if (i != j && A[i] == 2 * A[j]) {
                printf("(%d, %d)\n", A[i], A[j]);
            }
        }
    }

    return 0;
}
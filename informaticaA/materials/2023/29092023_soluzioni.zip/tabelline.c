#include <stdio.h>
/*
Scrivere un programma in C che stampa le tabelline, usando cicli while
*/

int main() {

    int i = 1, j;

    // per ogni riga
    while (i <= 10) {
        j=1;

        // per ogni colonna
        while (j <= 10) {
            printf("%2d ", i*j);
            j++;
        }
        printf("\n");
        i++;
    }

    return 0;
}
#include <stdio.h>
/*
Scrivere un programma in C che stampa la tabella ASCII
*/

int main() {

    char c;

    c = 0;

    // fin che non va in overflow
    while (c>= 0 && c<=127) {
        printf("%3d %c\n", c, c);
        c++;
    }

    return 0;
}
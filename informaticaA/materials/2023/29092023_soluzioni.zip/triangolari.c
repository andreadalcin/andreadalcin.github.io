#include <math.h>
#include <stdio.h>
/*
Acquisisce un numero intero positivo dall’utente 
Stabilisce se è un numero triangolare. Se lo è, stampa un messaggio di conferma e termina. 
Altrimenti, ne acquisisce un altro e ripete il controllo. 

Nota: Un numero triangolare è un numero formato dalla somma dei primi N numeri naturali, 
per qualche N fissato. (Ad esempio, sono numeri triangolari 3 = 1 + 2, 6 = 1 + 2 + 3, 
10 = 1 + 2 + 3 + 4, ecc.)
*/


int main() {

    int num, sum, n;
    int triangolare = 0;

    // fino a quando non inserisco un numero triangolare
    while (triangolare == 0) {
        do {
            printf("Inserire un intero positivo: ");
            scanf("%d", &num);
        } while (num <= 0);

        sum = 0;
        n = 1;

        // sommo gli interi fino a quando non raggiungo o supero il numero inserito
        while(sum < num) {
            sum += n;
            n++;
        }

        if (sum == num) {
            printf("%d è triangolare\n", num);
            triangolare = 1;
        }
        else
            printf("%d non è triangolare\n", num);

    }

    if (num > 0) {}

    return 0;
}

#include <stdio.h>

float pow(float, int);
void pow_(float, int, float*);
int abs(int);

int main() {
    float res;
    res = pow(2.0f, -3);
    printf("%f\n", res);
    pow_(2.0f, 5, &res);
    printf("%f\n", res);
    return 0;
}

float pow(float base, int exp) {
    int i;
    float pow = 1.0f;

    if (exp == 0) {
        return 0;
    }
    if (exp < 0) {
        base = 1.0f / base;
    }

    for (i = 0; i < abs(exp); i++) {
        pow *= base;
    }
    return pow;
}

void pow_(float base, int exp, float *res) {
    *res = pow(base, exp);
}

int abs(int a) {
    if (a > 0) {
        return a;
    } else {
        return -a;
    }
}
#include <stdio.h>

#define N 100

int f(int);
void f_(int, int *);
void f_msg(int, char *);

int main() {
    char msg[N];
    int num;

    printf("Inserisci un numero: ");
    scanf("%d", &num);

    f_msg(num, msg);
    printf("%s", msg);

    return 0;
}

int f(int num) {
    int div, sum = 0;
    for (div = 1; div < num; div++) {
        if (num % div == 0) {
            sum += div;
        }
    }
    return sum - num;
}

void f_(int num, int *res) {
    *res = f(num);
}

void f_msg(int num, char *msg) {
    int res = f(num);
    if (res == 0) {
        sprintf(msg, "Il numero %d è perfetto", num);
    } else if (res > 0) {
        sprintf(msg, "Il numero %d è abbondante", num);
    } else {
        sprintf(msg, "Il numero %d è difettivo", num);
    }
}
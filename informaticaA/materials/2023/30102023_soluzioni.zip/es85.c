#include <stdio.h>

#define N 100

int is_vowel(char c);

int solve(char *, char **);

int main() {
    char in[N] = "bcdaeioubcdef", out[N];
    char *substr;
    int i, len;

    len = solve(in, &substr);

    if (len <= 0) {
        printf("Sotto-stringa non trovata!");
        return 0;
    }

    // Copia sotto-stringa
    for (i = 0; i < len; i++) {
        out[i] = *(substr + i);
    }
    out[i] = '\0';

    printf("%s", out);

    return 0;
}

int solve(char *str, char **substr) {
    int i, j;

    for (i = 0; str[i] != '\0'; ++i) {
        if (is_vowel(str[i])) {
            for (j = i + 1; str[j] != '\0'; j++) {
                if (is_vowel(str[j]) == 0) {
                    // Found it!
                    *substr = &str[i];
                    return j - i;
                }
            }
        }
    }

    return -1;
}

int is_vowel(char c) {
    return c == 'a' || c == 'e' || c == 'o' || c == 'u' || c == 'i';
}
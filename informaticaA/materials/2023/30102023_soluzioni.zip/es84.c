#include <stdio.h>
#include <limits.h>

#define N 5

double abs_d(double a1);

double mean(const int V[N]);

void copy(const int src[N], int dst[N]);

double solve(int M[N][N], int V[N], int K);


int main() {
    int M[N][N] = {16, 0, 3, 0, 0,
                   3, 1, 1, 2, 1,
                   0, 0, 13, 0, 0,
                   0, 7, 2, 3, 2,
                   0, 5, 1, 6, 4};
    int V[N];
    int K = 2;

    double dist = solve(M, V, K);

    printf("Riga con media più vicina a K = %d\n", K);
    printf("Distanza in val. assoluto: %lf\n", dist);
    for (int i = 0; i < N; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", V[i]);
    }

    return 0;
}


double solve(int M[N][N], int V[N], int K) {
    int r = -1;
    double min_dist = INT_MAX;

    for (int i = 0; i < N; i++) {
        double dist = abs_d(mean(M[i]) - K);
        if (min_dist > dist) {
            min_dist = dist;
            r = i;
        }
    }

    copy(M[r], V);
    return min_dist;
}

void copy(const int src[N], int dst[N]) {
    for (int i = 0; i < N; ++i) {
        dst[i] = src[i];
    }
}

double abs_d(double a1) {
    if (a1 < 0) {
        return -a1;
    }
    return a1;
}

double mean(const int V[N]) {
    double s = 0.0f;
    for (int i = 0; i < N; i++) {
        s += V[i];
    }
    return s / N;
}
#include <stdio.h>

#define N 10

int count_special(const int arr[N], int len);

int is_special(const int arr[N], int len, int index);

/*
 * Given an integer array A of size N. You need to count the number of special elements in the given array.
 * A element is special if removal of that element make the array balanced.
 * Array will be balanced if sum of even index element equal to sum of odd index element.
 */
int main() {
    int arr[N] = {5, 5, 2, 5, 8};
    int len = 5;

    int cnt = count_special(arr, len);
    printf("Il numero di caratteri speciali è: %d", cnt);

    return 0;
}

int count_special(const int arr[N], int len) {
    int cnt = 0;
    for (int i = 0; i < len; i++) {
        if (is_special(arr, len, i)) {
            cnt++;
        }
    }
    return cnt;
}

int is_special(const int arr[N], int len, int index) {
    int s_even = 0, s_odd = 0;
    for (int i = 0; i < len; i++) {
        if (i != index) {
            if (i < index) {
                if (i % 2) {
                    s_even += arr[i];
                } else {
                    s_odd += arr[i];
                }
            } else {
                if ((i - 1) % 2) {
                    s_even += arr[i];
                } else {
                    s_odd += arr[i];
                }
            }
        }
    }
    return s_even == s_odd;
}
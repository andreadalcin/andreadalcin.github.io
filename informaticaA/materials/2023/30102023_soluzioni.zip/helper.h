#include <stdio.h>
#define N 10

void print_vec(const int *vec, int len);

void print_mat(int mat[][N], int rows, int cols);


#include <stdio.h>
#include "helper.h"

void print_vec(const int *vec, int len) {
    printf("[");
    for (int i = 0; i < len; ++i) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", *(vec + i));
    }
    printf("]");
}

void print_mat(int mat[][N], int rows, int cols) {
    printf("[");
    for (int i = 0; i < rows; i++) {
        printf("[");
        for (int j = 0; j < cols; ++j) {
            if (j > 0) {
                printf(", ");
            }
            printf("%d", mat[i][j]);
        }

        printf("]");
        if (i + 1 < rows) {
            printf("\n");
        }
    }
    printf("]\n");
}
#include <stdio.h>

#define N 5

int solve(int M[][N], int a[N]);

int main() {
    int M[N][N] = {16, 0, 3, 0, 0,
                   3, 1, 1, 2, 1,
                   0, 0, 13, 0, 0,
                   0, 7, 2, 3, 2,
                   0, 5, 1, 6, 4};

    int a[N];

    // Inizializza array
    for (int i = 0; i < N; ++i) {
        a[i] = -1;
    }

    // Copia da diagonale
    int len = solve(M, a);

    printf("Elementi copiati: ");
    for (int i = 0; i < len; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", a[i]);
    }

    return 0;
}


int solve(int M[][N], int a[N]) {
    int k = 0, flag;

    for (int i = 0; i < N; i++) {
        flag = 0;

        for (int u = 0; u < N && flag == 0; u++) {
            for (int v = u + 1; v < N && flag == 0; v++) {
                if (M[u][v] == M[i][i]) {
                    a[k++] = M[i][i];
                    flag = 1;
                }
            }
        }
    }

    return k;
}
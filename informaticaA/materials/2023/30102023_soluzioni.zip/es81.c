#include <stdio.h>
#include "helper.h"

void find_even(int [][N], int, int, int [N * N][2], int *);

int main() {
    int rows, cols;
    int M[N][N];

    // Popola la matrice
    rows = 3;
    cols = 4;

    M[0][0] = 1;
    M[0][1] = 2;
    M[0][2] = 3;
    M[0][3] = 4;
    M[1][0] = 5;
    M[1][1] = 6;
    M[1][2] = 7;
    M[1][3] = 8;
    M[2][0] = 9;
    M[2][1] = 10;
    M[2][2] = 11;
    M[2][3] = 12;

    print_mat(M, rows, cols);

    // Trova indici di numeri pari
    int indices[N * N][2];
    int n_indices;

    find_even(M, rows, cols, indices, &n_indices);

    // Stampa gli indici
    printf("I numeri pari sono agli indici:\n");
    for (int i = 0; i < n_indices; i++) {
        int u = indices[i][0];
        int v = indices[i][1];
        printf("(%d, %d): %d\n", u, v, M[u][v]);
    }

    return 0;
}

void find_even(int M[][N], int rows, int cols, int indices[N * N][2], int *n_indices) {
    *n_indices = 0;

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (M[i][j] % 2 == 0) {
                indices[*n_indices][0] = i;
                indices[*n_indices][1] = j;
                (*n_indices)++;
            }
        }
    }
}
#include <stdio.h>

#define N 100

int abs(int num);
int f(int *, int, int);

int main() {
    int seq[N] = {1, 2, 5, 8, 1};
    int k = 3, len = 5;
    int c = f(seq, len, k);

    printf("La sequenza di lunghezza massima è: %d\n", c);

    return 0;
}

int f(int *seq, int len, int k) {
    int i, c = 0, max_c = 0;
    for (i = 0; i < len - 1; i++) {
        if (abs(seq[i + 1] - seq[i]) == k) {
            c++;
            if (c > max_c) {
                max_c = c;
            }
        } else {
            c = 0;
        }
    }
    return max_c;
}

int abs(int num) {
    if (num < 0) {
        return -num;
    } else {
        return num;
    }
}

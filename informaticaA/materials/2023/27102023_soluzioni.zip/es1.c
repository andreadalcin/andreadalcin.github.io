#include <stdio.h>
#include "string.h"

#define N 100

int in(char, char *);
void f(char *, char *);

int main() {
    char src[N] = "gracchiare";
    char des[N] = "atte";

    printf("%s\n", src);
    f(src, des);
    printf("%s\n", src);

    return 0;
}

int in(char c, char *s) {
    int i;
    for (i = 0; i < strlen(s); ++i) {
        if (s[i] == c) {
            return 1;
        }
    }
    return 0;
}

void f(char *s1, char *s2) {
    int i, j;
    for (i = 0; i < strlen(s1); i++) {
        if (in(s1[i], s2) == 0)
            continue;

        for (j = i + 1; j < strlen(s1); j++) {
            s1[j - 1] = s1[j];
        }
        s1[j - 1] = '\0';
    }
}

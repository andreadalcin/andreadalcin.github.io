#include <stdio.h>

#define N 100
#define M 100

int f(int mat[N][M], int, int);
int min(int, int);
int max(int, int);
void printMat(int mat[N][M], int r, int c);

// Solo una demo su come accedere a una matrice tramite puntatore semplice (MOLTO sconsigliato all'esame).
int f_(const int *mat, int, int, int);

int main() {
    int mat[N][M] = {{1, 2, 1},
                     {2, 2, 2},
                     {1, 2, 2}};
    int r = 3, c = 3;
    printMat(mat, r, c);

    int cnt = f(mat, r, c);
    // int cnt = f_((const int *) mat, r, c, M);
    printf("Il numero di elementi circondati da numeri pari è: %d", cnt);

    return 0;
}

int f(int mat[N][M], int r, int c) {
    int flag;       // 0 se elemento è circondato da numeri pari, else 1
    int cnt = 0;    // numero di elementi della matrice circondati da numeri pari
    int i, j, u, v;

    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) {
            flag = 0;
            for (u = max(i - 1, 0); u <= min(i + 1, r - 1) && flag == 0; u++) {
                for (v = max(j - 1, 0); v <= min(j + 1, c - 1) && flag == 0; v++) {
                    if (mat[u][v] % 2 != 0 && (u != i || v != j)) {
                        flag = 1;
                    }
                }
            }
            if (flag == 0) {
                cnt++;
            }
        }
    }

    return cnt;
}

/* Per passare la matrice come puntatore semplice (sconsigliato), non basta passare la matrice e le dimensioni
 * effettive della stessa, in quanto abbiamo bisogno di conoscere il numero di "colonne" (asse 1) della matrice per
 * poter accedere all'elemento (i,j) desiderato. */
int f_(const int *mat, int r, int c, int DIM1) {
    int flag;       // 0 se elemento è circondato da numeri pari, else 1
    int cnt = 0;    // numero di elementi della matrice circondati da numeri pari
    int i, j, u, v;

    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) {
            flag = 0;
            for (u = max(i - 1, 0); u <= min(i + 1, r - 1) && flag == 0; u++) {
                for (v = max(j - 1, 0); v <= min(j + 1, c - 1) && flag == 0; v++) {
                    // Nota: non posso scrivere mat[u][v] se passo la matrice come puntatore semplice
                    int val = *(mat + DIM1 * u + v);
                    if (val % 2 != 0 && (u != i || v != j)) {
                        flag = 1;
                    }
                }
            }
            if (flag == 0) {
                cnt++;
            }
        }
    }

    return cnt;
}

int min(int a, int b) {
    if (a > b) {
        return b;
    } else {
        return a;
    }
}

int max(int a, int b) {
    if (a > b) {
        return a;
    } else {
        return b;
    }
}

void printMat(int mat[N][M], int r, int c) {
    printf("[");
    for (int i = 0; i < r; ++i) {
        printf("[");
        for (int j = 0; j < c; ++j) {
            if (j > 0) {
                printf(", ");
            }
            printf("%d", mat[i][j]);
        }
        printf("]");
        if (i + 1 < N) {
            printf("\n");
        }
    }
    printf("]\n");
}

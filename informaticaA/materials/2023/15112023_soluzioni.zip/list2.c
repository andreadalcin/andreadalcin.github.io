#include "stdio.h"
#include "stdlib.h"
#include "limits.h"

typedef struct elem_t {
    int val;
    struct elem_t *next;
} elem_t;

elem_t *insert_last(elem_t *list, int val);
int min(elem_t *list);

int main() {
    elem_t *list = NULL;
    list = insert_last(list, 0);
    list = insert_last(list, 2);
    list = insert_last(list, 3);
    list = insert_last(list, 4);

    printf("%d è l'elemento minimo nella lista\n", min(list));

    return 0;
}

int min(elem_t *list) {
    int val = INT_MAX;
    if (list == NULL) {
        return val;
    }

    for (elem_t *cur = list; cur != NULL; cur = cur->next) {
        if (cur->val < val) {
            val = cur->val;
        }
    }

    return val;
}

elem_t *insert_last(elem_t *list, int val) {
    elem_t *ptr = (elem_t *) malloc(sizeof(elem_t));
    ptr->val = val;
    ptr->next = NULL;

    // Gestione lista vuota
    if (list == NULL) {
        return ptr;
    }

    // Vai a ultimo elemento e aggiungi in coda
    elem_t *cur;
    for (cur = list; cur->next != NULL; cur = cur->next) {}
    cur->next = ptr;

    return list;
}
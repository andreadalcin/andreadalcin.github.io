#include "stdio.h"
#include "stdlib.h"

typedef struct elem_t {
    int val;
    struct elem_t *next;
} elem_t;

elem_t *insert_last(elem_t *list, int val);
elem_t *search_and_prefix_insert(elem_t *list, int x);
void search_and_postfix_insert(elem_t *list, int x);

int main() {
    /*
     * Questo da esercitazione, penso però sia meglio definire una funzione che inserisce elementi nella lista.
    elem_t *list = (elem_t *) malloc(sizeof(elem_t));
    list->val = 0;
    list->next = malloc(sizeof(elem_t));
    list->next->val = 2;
    list->next->next = malloc(sizeof(elem_t));
    list->next->next->val = 3;
    list->next->next->next = malloc(sizeof(elem_t));
    list->next->next->next->val = 4;
    list->next->next->next->next = NULL;
     */

    elem_t *list = NULL;
    list = insert_last(list, 0);
    list = insert_last(list, 2);
    list = insert_last(list, 3);
    list = insert_last(list, 4);

    // Inserisci elemento in posizione antecedente a quello trovato
    list = search_and_prefix_insert(list, 3);

    // Inserisci elemento in posizione successiva a quello trovato
    search_and_postfix_insert(list, 0);

    return 0;
}

elem_t *search_and_prefix_insert(elem_t *list, int x) {
    /* Gestione casi limite */
    // 1. Lista vuota
    if (list == NULL) {
        return NULL;
    }
    // 2. Il primo elemento ha valore pari a x
    if (list->val == x) {
        elem_t *ptr = (elem_t *) malloc(sizeof(elem_t));
        ptr->val = x;
        ptr->next = list;
        return ptr;
    }

    /* Gestione caso generico */
    elem_t *prev = list;
    elem_t *cur = list->next;

    while (cur != NULL) {
        if (cur->val == x) {
            break;
        }
        prev = cur;
        cur = cur->next;
    }

    // Se cur == NULL, l'elemento non è stato trovato.
    if (cur == NULL) {
        return list;
    }

    // Altrimenti aggiungo un nuovo elemento tra 'prev' e 'cur'
    elem_t *ptr = (elem_t *) malloc(sizeof(elem_t));
    ptr->val = x;
    ptr->next = cur;
    prev->next = ptr;

    return list;
}

void search_and_postfix_insert(elem_t *list, int x) {
    /* Gestione casi limite */
    // 1. Lista vuota
    if (list == NULL) {
        return;
    }

    /* Gestione caso generico */
    elem_t *cur;
    for (cur = list; cur != NULL; cur = cur->next) {
        if (cur->val == x) {
            break;
        }
    }

    elem_t *ptr = (elem_t *) malloc(sizeof(elem_t));
    ptr->val = x;
    ptr->next = cur->next;
    cur->next = ptr;
}

elem_t *insert_last(elem_t *list, int val) {
    elem_t *ptr = (elem_t *) malloc(sizeof(elem_t));
    ptr->val = val;
    ptr->next = NULL;

    // Gestione lista vuota
    if (list == NULL) {
        return ptr;
    }

    // Vai a ultimo elemento e aggiungi in coda
    elem_t *cur;
    for (cur = list; cur->next != NULL; cur = cur->next) {}
    cur->next = ptr;

    return list;
}
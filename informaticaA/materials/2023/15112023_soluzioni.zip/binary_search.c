#include <stdio.h>

#define SUCCESS (-1)
#define FAIL (-2)

int binary_search(int *a, int lhs, int rhs, int k);

int main() {
    int vet[] = {2, 4, 5, 10, 22, 70, 89, 99, 100};
    int len = 9;

    // Testiamo qualche caso
    for (int i = 0; i <= 100; ++i) {
        if (binary_search(vet, 0, len, i) == SUCCESS) {
            printf("%d è contenuto nella lista\n", i);
        } else {
            printf("%d NON è contenuto nella lista\n", i);
        }
    }

    return 0;
}

int binary_search(int *a, int lhs, int rhs, int k) {
    // Caso base
    if (lhs == rhs && a[lhs] == k) {
        return SUCCESS;
    } else if (lhs >= rhs) {
        return FAIL;
    }

    // Elemento centrale del vettore
    int mid = (rhs - lhs - 1) / 2 + lhs;

    if (a[mid] == k) {
        // Abbiamo trovato l'elemento
        return SUCCESS;
    } else if (a[mid] > k) {
        // Controlla il sotto-vettore sx
        return binary_search(a, lhs, mid, k);
    } else { // a[0] = 1
        // Controlla il sotto-vettore dx
        return binary_search(a, mid + 1, rhs, k);
    }
}

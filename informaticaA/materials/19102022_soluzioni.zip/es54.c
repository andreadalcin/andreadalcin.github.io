#include <stdio.h>
#include <string.h>

#define MAX_C 30

typedef struct {
    char nome[20], cognome[20];
    int eta;
} Studente;

typedef struct {
    char lingua[10];
    int livello;
    int n_iscritti;
    char nome_prof[20];
    Studente iscritti[10];
} Corso;


int main() {
    int i, j, n_corsi, n_inglese;
    int somma_eta;

    Corso scuola[MAX_C] = {
            {"inglese",  1, 2, "maestr1", "alice", "ferrari", 8,  "luca",   "bianchi", 8},
            {"inglese",  2, 2, "maestr2", "guzzi", "tommi",   18, "gialli", "fede",    18},
            {"inglese",  1, 2, "maestr3", "innoi", "ldddd",   10, "sssss",  "ddddd",   10},
            {"spagnolo", 2, 2, "maestr4", "ducai", "ddddd",   5,  "wwwww",  "qqqqq",   5}
    };
    n_corsi = 4;

    somma_eta = 0;
    n_inglese = 0;

    for (i = 0; i < n_corsi; i++) {
        if (strcmp(scuola[i].lingua, "inglese") == 0) {
            n_inglese += scuola[i].n_iscritti;
            for (j = 0; j < scuola[i].n_iscritti; j++) {
                somma_eta += scuola[i].iscritti[j].eta;
            }
        }
    }

    if (n_inglese <= 0) {
        printf("Non ci sono studenti che seguono un corso di inglese");
    } else {
        printf("L'età media degli studenti che seguono un corso di inglese è: %f", (float) somma_eta / (float) n_inglese);
    }

    return 0;
}

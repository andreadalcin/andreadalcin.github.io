#include <stdio.h>
#include <string.h>

#define N_POKEMON 151

typedef struct {
    char nome[100];
    char tipo[20];
    int n_abilita;
    char abilita[2][100];
} Pokemon ;

int main() {
    Pokemon pokedex[N_POKEMON];
    int i, j, k;

    for (i = 0; i < N_POKEMON; i++) {
        pokedex[i].n_abilita = 0;
    }

    Pokemon pikachu = { "Pikachu", "Elettrico", 2 };
    strcpy(pikachu.abilita[0], "Statico");
    strcpy(pikachu.abilita[1], "Parafulmine");

    Pokemon eevee = { "Eevee", "Normale", 2 };
    strcpy(eevee.abilita[0], "Fugafacile");
    strcpy(eevee.abilita[1], "Adattabilità");

    Pokemon charizard = { "Charizard", "Fuoco", 1 };
    strcpy(charizard.abilita[0], "Aiutofuoco");

    Pokemon ponyta = { "Ponyta", "Fuoco", 1 };
    strcpy(ponyta.abilita[0], "Fugafacile");

    pokedex[6 - 1] = charizard;
    pokedex[25 - 1] = pikachu;
    pokedex[133 - 1] = eevee;
    pokedex[77 - 1] = ponyta;

    /* 1: Stampa il nome del Pokémon numero #25 */
    printf("Il Pokémon #25 è %s\n", pokedex[25 - 1].nome);

    /* 2: Trova il numero del Pokédex di Eevee */

    for (i = 0; i < N_POKEMON; i++) {
        if (strcmp(pokedex[i].nome, "Eevee") == 0) {
            break;
        }
    }
    printf("Eevee è il #%d\n", i + 1);

    /* 3: Copia in un vettore tutti i Pokémon di tipo fuoco */
    Pokemon fuoco[N_POKEMON];
    j = 0;

    for (i = 0; i < N_POKEMON; i++) {
        if (strcmp(pokedex[i].tipo, "Fuoco") == 0) {
            fuoco[j++] = pokedex[i];
        }
    }

    printf("I Pokémon di tipo 'Fuoco' sono: \n");
    for (i = 0; i < j; i++) {
        printf("%s\n", fuoco[i].nome);
    }

    /* 4: Copia in un vettore tutti i Pokémon con abilità fugafacile */
    Pokemon fugafacile[N_POKEMON];
    k = 0;

    for (i = 0; i < N_POKEMON; i++) {
        for (j = 0; j < pokedex[i].n_abilita; j++) {
            if (strcmp(pokedex[i].abilita[j], "Fugafacile") == 0) {
                fugafacile[k++] = pokedex[i];
                break;
            }
        }
    }

    printf("I Pokémon con abilità 'Fugafacile' sono: \n");
    for (i = 0; i < k; i++) {
        printf("%s\n", fugafacile[i].nome);
    }
}
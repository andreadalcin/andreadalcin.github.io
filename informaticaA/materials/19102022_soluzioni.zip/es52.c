#include <stdio.h>
#include <string.h>
#include <limits.h>

typedef struct {
    char targa[7 + 1];
    char marca[15 + 1];
    char modello[20 + 1];
    int cilindrata;
    float potenza;
    char categoria[16 + 1];
} Motoveicolo;

typedef struct {
    char nome[30 + 1];
    char cognome[40 + 1];
    char codice_fiscale[16 + 1];
} Proprietario;

typedef struct {
    Motoveicolo motoveicolo;
    Proprietario proprietario;
} VocePRA;

typedef struct {
    VocePRA elementi[10000];
    int n_elementi;
} PRA;


int main() {
    PRA pra;
    Proprietario pr;
    int i, j, cc;
    int max_cc = INT_MIN;

    /* Per casa: far inserire all'utente informazioni */

    // Trovo il proprietario con la cilindrata più alta
    for (i = 0; i < pra.n_elementi; i++) {
        if (pra.elementi[i].motoveicolo.cilindrata > max_cc) {
            max_cc = pra.elementi[i].motoveicolo.cilindrata;
            pr = pra.elementi[i].proprietario;
        }
    }

    printf("Il proprietario con cilindrata più alta (%d) è %s %s", max_cc, pr.nome, pr.cognome);


    // Trovo il proprietario con la somma delle cilindrate delle sue auto maggiore
    max_cc = INT_MIN;

    for (i = 0; i < pra.n_elementi; i++) {
        cc = 0;
        for (j = 0; j < pra.n_elementi; j++) {
            // Filtra le voci che contengono il proprietario corretto
            if (strcmp(pra.elementi[i].proprietario.codice_fiscale, pra.elementi[j].proprietario.codice_fiscale) == 0) {
                cc += pra.elementi[j].motoveicolo.cilindrata;
            }
        }
        if (cc > max_cc) {
            max_cc = cc;
            pr = pra.elementi[i].proprietario;
        }
    }

    printf("Il proprietario con somma di cilindrate più alta (%d) è %s %s", max_cc, pr.nome, pr.cognome);

    return 0;
}

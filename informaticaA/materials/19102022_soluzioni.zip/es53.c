#include <stdio.h>
#include <string.h>

#define N_PIANI 20
#define N_UFFICI 40

typedef struct {
    char nome[20], cognome[20];
    int stipendio;
    int cat; // contiene valori tra 1 e 5 int stipendio;
} Impiegato;

typedef struct {
    int superficie; /*in m^2*/
    char esp[20];
    Impiegato occupante;
} Ufficio;


int main() {
    // Definizione delle variabili
    Ufficio torre[N_PIANI][N_UFFICI];   /* edificio di 20 piani con 40 uffici per piano */
    Ufficio uff1 = {15, "sudEst", {"Giacomo", "Boracchi", 2000, 5}};
    torre[0][0] = uff1;
    Ufficio uff2 = {10, "nord", {"Andrea", "Porfiri", 1500, 3}};
    torre[1][0] = uff2;

    int p, u;       /* indice di piano nell’edificio e di ufficio nel piano */
    int uffNord;    /* uffNord fa da flag*/
    Ufficio vett1[20 * 40];
    Impiegato vett2[20 * 40];
    int i, j;

    /* Punto 1: Stampa cognome, stipendio e categoria degli impiegati che occupano uffici a sud o a sud-est con
     * superficie tra 20 e 30 metri quadri */
    for (p = 0; p < N_PIANI; p++) {
        for (u = 0; u < N_UFFICI; u++) {
            if ((strcmp(torre[p][u].esp, "sud") == 0 || strcmp(torre[p][u].esp, "sudEst") == 0) &&
                torre[p][u].superficie >= 20 && torre[p][u].superficie <= 30) {
                printf("%s %s, stipendio: %d, categoria %d\n",
                       torre[p][u].occupante.nome,
                       torre[p][u].occupante.cognome,
                       torre[p][u].occupante.stipendio,
                       torre[p][u].occupante.cat);
            }
        }
    }

    /* Punto 2: Stampa piani senza uffici esposti a nord */
    for (p = 0; p < N_PIANI; p++) {
        uffNord = 0;
        for (u = 0; u < N_UFFICI && uffNord != 1; u++) {
            if (strcmp(torre[p][u].esp, "nord") == 0) {
                uffNord = 1;
            }
        }
        if (uffNord == 0) {
            printf("Il piano %d non ha edifici esposti a nord\n", p);
        }
    }

    /* Punto 3: Cerca l'ufficio del Prof. Boracchi */
    for (p = 0; p < N_PIANI; p++) {
        for (u = 0; u < N_UFFICI; u++) {
            if (strcmp(torre[p][u].occupante.cognome, "Boracchi") == 0 &&
                strcmp(torre[p][u].occupante.nome, "Giacomo") == 0) {
                printf("L'ufficio del Prof. Boracchi è il numero %d al piano %d\n", u, p);
            }
        }
    }

    /* Punto 4: Copia uffici di dipendenti di categoria 5 in vettore */
    i = 0;
    for (p = 0; p < N_PIANI; p++) {
        for (u = 0; u < N_UFFICI; u++) {
            if (torre[p][u].occupante.cat == 5) {
                vett1[i] = torre[p][u];
                i++;
            }
        }
    }

    /* Punto 5: Copia dipendenti di categoria 5 in vettore */
    for (j = 0; j < i; i++) {
        vett2[i] = vett1[j].occupante;
    }

    return 0;
}
